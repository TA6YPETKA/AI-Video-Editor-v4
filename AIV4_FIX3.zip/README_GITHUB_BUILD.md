# AI Video Editor v4 — Android build package

This archive contains the Android Gradle project only.
It is intended to be built by the companion GitHub Actions workflow `build-apk.yml`.

Expected output:
`app/build/outputs/apk/debug/app-debug.apk`
