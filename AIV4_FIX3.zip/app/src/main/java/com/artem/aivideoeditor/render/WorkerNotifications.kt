package com.artem.aivideoeditor.render

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.ForegroundInfo
import com.artem.aivideoeditor.MainActivity
import com.artem.aivideoeditor.R
import com.artem.aivideoeditor.VideoEditorApp

fun renderForegroundInfo(context: Context, notificationId: Int, title: String, text: String, progress: Int, mediaProcessing: Boolean = false): ForegroundInfo {
    val intent = Intent(context, MainActivity::class.java)
    val pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val notification = NotificationCompat.Builder(context, VideoEditorApp.RENDER_CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_upload)
        .setContentTitle(title)
        .setContentText(text)
        .setContentIntent(pi)
        .setOnlyAlertOnce(true)
        .setOngoing(progress in 0..99)
        .setProgress(100, progress.coerceIn(0,100), progress < 0)
        .build()
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val type = if (mediaProcessing && Build.VERSION.SDK_INT >= 35) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
        } else {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        }
        ForegroundInfo(notificationId, notification, type)
    } else {
        ForegroundInfo(notificationId, notification)
    }
}
