package com.artem.aivideoeditor.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(context: Context) {
    private val root = File(context.filesDir, "projects").apply { mkdirs() }
    private val index = File(root, "index.json")
    private val lock = Any()

    fun list(): List<EditProject> = synchronized(lock) { load().sortedByDescending { it.updatedAt } }
    fun get(id: String): EditProject? = list().firstOrNull { it.id == id }

    fun create(assetIds: List<String>): EditProject = synchronized(lock) {
        val now = System.currentTimeMillis()
        val p = EditProject(
            id = UUID.randomUUID().toString(), title = "Новый проект", assetIds = assetIds.distinct(),
            prompt = "", createdAt = now, updatedAt = now
        )
        val all = load().toMutableList().apply { add(p) }
        save(all); p
    }

    fun saveProject(project: EditProject): EditProject = synchronized(lock) {
        val p = project.copy(updatedAt = System.currentTimeMillis())
        val all = load().toMutableList()
        val i = all.indexOfFirst { it.id == p.id }
        if (i >= 0) all[i] = p else all += p
        save(all); p
    }

    fun delete(id: String) = synchronized(lock) {
        val all = load().filterNot { it.id == id }
        save(all)
    }

    private fun load(): List<EditProject> {
        if (!index.exists()) return emptyList()
        return try {
            val a = JSONArray(index.readText())
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val ids = o.optJSONArray("assetIds") ?: JSONArray()
                    add(EditProject(
                        id = o.getString("id"), title = o.optString("title", "Проект"),
                        assetIds = List(ids.length()) { j -> ids.getString(j) }, prompt = o.optString("prompt"),
                        ratio = o.optString("ratio", "9:16"), durationSec = o.optInt("durationSec", 30),
                        style = o.optString("style", "auto"), quality = o.optString("quality", "standard"),
                        fps = o.optInt("fps", 30), mode = o.optString("mode", "cloud"),
                        removePauses = o.optBoolean("removePauses", true), captions = o.optBoolean("captions", true),
                        beatSync = o.optBoolean("beatSync", true), createdAt = o.optLong("createdAt"),
                        updatedAt = o.optLong("updatedAt")
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(items: List<EditProject>) {
        val a = JSONArray()
        items.forEach { p ->
            a.put(JSONObject().apply {
                put("id", p.id); put("title", p.title); put("assetIds", JSONArray(p.assetIds)); put("prompt", p.prompt)
                put("ratio", p.ratio); put("durationSec", p.durationSec); put("style", p.style); put("quality", p.quality)
                put("fps", p.fps); put("mode", p.mode); put("removePauses", p.removePauses); put("captions", p.captions)
                put("beatSync", p.beatSync); put("createdAt", p.createdAt); put("updatedAt", p.updatedAt)
            })
        }
        val tmp = File(root, ".index.tmp"); tmp.writeText(a.toString())
        if (!tmp.renameTo(index)) { tmp.copyTo(index, overwrite = true); tmp.delete() }
    }
}
