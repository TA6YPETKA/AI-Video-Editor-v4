package com.artem.aivideoeditor.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

class LibraryRepository(private val context: Context) {
    private val root = File(context.filesDir, "library").apply { mkdirs() }
    private val thumbs = File(root, "thumbs").apply { mkdirs() }
    private val index = File(root, "index.json")
    private val lock = Any()

    fun list(): List<MediaAsset> = synchronized(lock) {
        load().sortedByDescending { it.createdAt }
    }

    fun find(id: String): MediaAsset? = list().firstOrNull { it.id == id }

    fun importUris(uris: List<Uri>): List<MediaAsset> = synchronized(lock) {
        val current = load().toMutableList()
        val known = current.associateBy { it.sha256 }.toMutableMap()
        val added = mutableListOf<MediaAsset>()

        for (uri in uris.distinct()) {
            val id = UUID.randomUUID().toString()
            val displayName = queryName(uri) ?: "video_${System.currentTimeMillis()}.mp4"
            val rawExtension = displayName.substringAfterLast('.', "mp4").lowercase()
            val extension = rawExtension.takeIf { it.matches(Regex("[a-z0-9]{1,8}")) } ?: "mp4"
            val temp = File(root, ".$id.part")
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output ->
                    val buf = ByteArray(1024 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        digest.update(buf, 0, n)
                        output.write(buf, 0, n)
                        total += n
                    }
                    output.fd.sync()
                }
            } ?: continue

            if (total <= 0L) {
                temp.delete()
                continue
            }
            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val duplicate = known[hash]
            if (duplicate != null) {
                temp.delete()
                continue
            }

            val dest = File(root, "$id.$extension")
            if (!temp.renameTo(dest)) {
                temp.copyTo(dest, overwrite = true)
                temp.delete()
            }
            val media = inspect(dest)
            if (media.first <= 0L || media.second <= 0 || media.third <= 0) {
                dest.delete()
                continue
            }
            val thumb = makeThumbnail(dest, id)
            val asset = MediaAsset(
                id = id,
                name = displayName,
                filePath = dest.absolutePath,
                thumbPath = thumb?.absolutePath,
                sha256 = hash,
                durationMs = media.first,
                width = media.second,
                height = media.third,
                sizeBytes = dest.length(),
                createdAt = System.currentTimeMillis(),
            )
            current += asset
            known[hash] = asset
            added += asset
        }
        save(current)
        added
    }

    fun toggleFavorite(id: String): Boolean = synchronized(lock) {
        val items = load().toMutableList()
        val idx = items.indexOfFirst { it.id == id }
        if (idx < 0) return@synchronized false
        val updated = items[idx].copy(favorite = !items[idx].favorite)
        items[idx] = updated
        save(items)
        updated.favorite
    }

    fun delete(id: String): Boolean = synchronized(lock) {
        val items = load().toMutableList()
        val item = items.firstOrNull { it.id == id } ?: return@synchronized false
        File(item.filePath).delete()
        item.thumbPath?.let { File(it).delete() }
        items.removeAll { it.id == id }
        save(items)
        true
    }

    private fun queryName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun inspect(file: File): Triple<Long, Int, Int> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            Triple(d, w, h)
        } catch (_: Exception) {
            Triple(0L, 0, 0)
        } finally { try { r.release() } catch (_: Exception) {} }
    }

    private fun makeThumbnail(file: File, id: String): File? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val bmp = r.getFrameAtTime(500_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val max = 512
            val scale = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height).coerceAtLeast(1))
            val scaled = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true
            ) else bmp
            val out = File(thumbs, "$id.jpg")
            FileOutputStream(out).use { scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, it) }
            if (scaled !== bmp) scaled.recycle()
            bmp.recycle()
            out
        } catch (_: Exception) { null }
        finally { try { r.release() } catch (_: Exception) {} }
    }

    private fun load(): List<MediaAsset> {
        if (!index.exists()) return emptyList()
        return try {
            val a = JSONArray(index.readText())
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val path = o.getString("filePath")
                    if (!File(path).exists()) continue
                    add(MediaAsset(
                        id = o.getString("id"), name = o.getString("name"), filePath = path,
                        thumbPath = o.optString("thumbPath").takeIf { it.isNotBlank() && it != "null" },
                        sha256 = o.getString("sha256"), durationMs = o.optLong("durationMs"),
                        width = o.optInt("width"), height = o.optInt("height"), sizeBytes = o.optLong("sizeBytes"),
                        createdAt = o.optLong("createdAt"), favorite = o.optBoolean("favorite", false)
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(items: List<MediaAsset>) {
        val arr = JSONArray()
        items.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("name", m.name); put("filePath", m.filePath); put("thumbPath", m.thumbPath)
                put("sha256", m.sha256); put("durationMs", m.durationMs); put("width", m.width); put("height", m.height)
                put("sizeBytes", m.sizeBytes); put("createdAt", m.createdAt); put("favorite", m.favorite)
            })
        }
        atomicWrite(index, arr.toString())
    }

    private fun atomicWrite(file: File, text: String) {
        val tmp = File(file.parentFile, ".${file.name}.tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }
}
