package com.artem.aivideoeditor

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.artem.aivideoeditor.data.ExportRepository
import com.artem.aivideoeditor.data.LibraryRepository
import com.artem.aivideoeditor.data.ProjectRepository
import com.artem.aivideoeditor.data.SettingsRepository

class VideoEditorApp : Application() {
    lateinit var library: LibraryRepository; private set
    lateinit var projects: ProjectRepository; private set
    lateinit var exports: ExportRepository; private set
    lateinit var settings: SettingsRepository; private set

    override fun onCreate() {
        super.onCreate()
        library = LibraryRepository(this)
        projects = ProjectRepository(this)
        exports = ExportRepository(this)
        settings = SettingsRepository(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(
                RENDER_CHANNEL, "Рендер видео", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Прогресс фонового монтажа и экспорта" })
        }
    }

    companion object { const val RENDER_CHANNEL = "video_render" }
}
