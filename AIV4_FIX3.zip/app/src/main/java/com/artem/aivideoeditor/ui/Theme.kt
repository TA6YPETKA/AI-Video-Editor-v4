package com.artem.aivideoeditor.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AppBg = Color(0xFF090A0E)
val AppCard = Color(0xFF12141B)
val AppCard2 = Color(0xFF181B24)
val Purple = Color(0xFF7C5CFF)
val Cyan = Color(0xFF67DDF3)
val Pink = Color(0xFFFF6FAE)
val Success = Color(0xFF5CE1A6)
val Muted = Color(0xFF969BA8)

private val scheme = darkColorScheme(
    primary = Purple,
    secondary = Cyan,
    tertiary = Pink,
    background = AppBg,
    surface = AppCard,
    surfaceVariant = AppCard2,
    onPrimary = Color.White,
    onSecondary = Color(0xFF061015),
    onBackground = Color(0xFFF5F5F7),
    onSurface = Color(0xFFF5F5F7),
    onSurfaceVariant = Color(0xFFB6BAC5),
    error = Color(0xFFFF6B6B),
)

@Composable
fun AIVideoEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
