package com.artem.aivideoeditor.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.artem.aivideoeditor.AppViewModel
import com.artem.aivideoeditor.ShareUtils
import com.artem.aivideoeditor.data.EditProject
import com.artem.aivideoeditor.data.ExportRecord
import com.artem.aivideoeditor.data.MediaAsset
import com.artem.aivideoeditor.render.RenderScheduler
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Screen { Home, Library, Editor, Exports, Settings }

@Composable
fun VideoEditorRoot(incomingUris: List<Uri>, consumeIncoming: () -> Unit, vm: AppViewModel = viewModel()) {
    AIVideoEditorTheme {
        val context = LocalContext.current
        var screenName by rememberSaveable { mutableStateOf(Screen.Home.name) }
        val screen = runCatching { Screen.valueOf(screenName) }.getOrDefault(Screen.Home)
        val selected = remember { mutableStateListOf<String>() }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.importVideos(uris)
        }

        LaunchedEffect(incomingUris) {
            if (incomingUris.isNotEmpty()) {
                vm.importVideos(incomingUris); screenName = Screen.Library.name; consumeIncoming()
            }
        }

        Scaffold(
            containerColor = AppBg,
            bottomBar = {
                if (screen != Screen.Editor && screen != Screen.Settings) {
                    NavigationBar(containerColor = Color(0xFF0D0F14), tonalElevation = 0.dp) {
                        BottomItem(screen == Screen.Home, Icons.Rounded.Home, "Главная") { screenName = Screen.Home.name }
                        BottomItem(screen == Screen.Library, Icons.Rounded.VideoLibrary, "Библиотека") { screenName = Screen.Library.name }
                        NavigationBarItem(
                            selected = false,
                            onClick = {
                                val ids = selected.toList().ifEmpty { vm.media.take(1).map { it.id } }
                                if (ids.isNotEmpty()) { vm.createProject(ids); screenName = Screen.Editor.name }
                                else { picker.launch(arrayOf("video/*")); screenName = Screen.Library.name }
                            },
                            icon = { Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, null, tint = Color.White) } },
                            label = { Text("Создать", fontSize = 11.sp) }
                        )
                        BottomItem(screen == Screen.Exports, Icons.Rounded.FileDownload, "Экспорт") { vm.refresh(); screenName = Screen.Exports.name }
                        BottomItem(false, Icons.Rounded.Settings, "Настройки") { screenName = Screen.Settings.name }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.Home -> HomeScreen(vm, onNew = {
                        val ids = selected.toList().ifEmpty { vm.media.take(1).map { it.id } }
                        if (ids.isEmpty()) { picker.launch(arrayOf("video/*")); screenName = Screen.Library.name }
                        else { vm.createProject(ids); screenName = Screen.Editor.name }
                    }, onOpenProject = { vm.openProject(it); screenName = Screen.Editor.name }, onLibrary = { screenName = Screen.Library.name })
                    Screen.Library -> LibraryScreen(vm, selected, onImport = { picker.launch(arrayOf("video/*")) }, onCreate = {
                        if (selected.isNotEmpty()) { vm.createProject(selected.toList()); selected.clear(); screenName = Screen.Editor.name }
                    })
                    Screen.Editor -> EditorScreen(vm, onBack = { screenName = Screen.Home.name }, onQueued = { vm.refresh(); screenName = Screen.Exports.name })
                    Screen.Exports -> ExportsScreen(vm)
                    Screen.Settings -> SettingsScreen(vm, onBack = { screenName = Screen.Home.name })
                }
            }
        }
    }
}

@Composable
private fun RowScope.BottomItem(selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, label) }, label = { Text(label, fontSize = 11.sp) })
}

@Composable
private fun HomeScreen(vm: AppViewModel, onNew: () -> Unit, onOpenProject: (String) -> Unit, onLibrary: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("AI Video Editor", fontWeight = FontWeight.Black, fontSize = 28.sp); Text("Монтаж из промпта — прямо с телефона", color = Muted) }
                Surface(shape = CircleShape, color = AppCard2) { Icon(Icons.Rounded.AutoAwesome, null, tint = Cyan, modifier = Modifier.padding(12.dp)) }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF4E36D8), Color(0xFF1C6B86), Color(0xFF11131B)))).clickable { onNew() }.padding(24.dp)) {
                Column(Modifier.fillMaxWidth()) {
                    Surface(color = Color.White.copy(alpha = .12f), shape = RoundedCornerShape(50)) { Text("NEW PROJECT", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(36.dp))
                    Text("Скажи, какой ролик нужен.\nОстальное — монтаж.", fontSize = 27.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Новый AI-монтаж", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("${vm.media.size}", "в библиотеке", Icons.Rounded.VideoLibrary, Modifier.weight(1f))
                StatCard("${vm.exports.size}", "готовых роликов", Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
        }
        item { SectionTitle("Последние проекты", "Все видео") { onLibrary() } }
        if (vm.projects.isEmpty()) item { EmptyCard("Проектов пока нет", "Добавь видео и создай первый монтаж.", Icons.Rounded.MovieCreation) }
        else items(vm.projects.take(6), key = { it.id }) { p ->
            Surface(onClick = { onOpenProject(p.id) }, color = AppCard, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(54.dp).background(Color(0xFF232636), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Movie, null, tint = Purple) }
                    Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(p.title, fontWeight = FontWeight.Bold); Text("${p.assetIds.size} клипов · ${p.ratio} · ${p.durationSec} сек.", color = Muted, fontSize = 13.sp) }
                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = AppCard, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Cyan); Spacer(Modifier.height(14.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Black); Text(label, color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun LibraryScreen(vm: AppViewModel, selected: MutableList<String>, onImport: () -> Unit, onCreate: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<MediaAsset?>(null) }
    val list = vm.media.filter { (!favoritesOnly || it.favorite) && (query.isBlank() || it.name.contains(query, true)) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Библиотека", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("Видео хранятся на этом устройстве", color = Muted, fontSize = 13.sp) }
            FilledTonalIconButton(onClick = onImport) { Icon(Icons.Rounded.Add, "Импорт") }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Поиск видео") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = !favoritesOnly }, label = { Text("Избранное") }, leadingIcon = { Icon(Icons.Rounded.Favorite, null, modifier = Modifier.size(18.dp)) })
            Spacer(Modifier.weight(1f)); Text("${list.size} видео", color = Muted, fontSize = 13.sp)
        }
        if (vm.importing) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.importMessage?.let { Text(it, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { EmptyCard("Библиотека пуста", "Импортируй видео из галереи или поделись роликом в это приложение.", Icons.Rounded.VideoLibrary, onImport) }
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 100.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                gridItems(list, key = { it.id }) { asset -> MediaTile(asset, selected.contains(asset.id), onToggle = {
                    if (selected.contains(asset.id)) selected.remove(asset.id) else selected.add(asset.id)
                }, onFavorite = { vm.toggleFavorite(asset.id) }, onDelete = { pendingDelete = asset }) }
            }
        }
        pendingDelete?.let { asset ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text("Удалить из библиотеки?") },
                text = { Text("${asset.name} будет удалён из хранилища приложения. Проекты, где он использовался, потеряют этот исходник.") },
                confirmButton = { TextButton(onClick = { selected.remove(asset.id); vm.deleteMedia(asset.id); pendingDelete = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) } },
                dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Отмена") } }
            )
        }
        AnimatedVisibility(selected.isNotEmpty()) {
            Surface(color = Color(0xFF1B1D27), shape = RoundedCornerShape(20.dp), tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Выбрано: ${selected.size}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Button(onClick = onCreate) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("В монтаж") }
                }
            }
        }
    }
}

@Composable
private fun MediaTile(asset: MediaAsset, selected: Boolean, onToggle: () -> Unit, onFavorite: () -> Unit, onDelete: () -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(if (selected) 2.dp else 0.dp, if (selected) Purple else Color.Transparent, RoundedCornerShape(18.dp)).clickable { onToggle() }) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF20232D))) {
                Thumb(asset.thumbPath, Modifier.fillMaxSize())
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(8.dp), color = Color.Black.copy(alpha=.48f), shape = CircleShape) {
                    IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) { Icon(if (asset.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if(asset.favorite) Pink else Color.White, modifier = Modifier.size(18.dp)) }
                }
                if (selected) Box(Modifier.align(Alignment.TopStart).padding(8.dp).size(28.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Check, null, modifier = Modifier.size(18.dp)) }
                Surface(modifier = Modifier.align(Alignment.BottomStart).padding(7.dp), color = Color.Black.copy(alpha=.48f), shape = CircleShape) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) { Icon(Icons.Rounded.DeleteOutline, "Удалить из библиотеки", tint = Color.White, modifier = Modifier.size(17.dp)) }
                }
                Text(formatDuration(asset.durationMs), modifier = Modifier.align(Alignment.BottomEnd).padding(7.dp).background(Color.Black.copy(alpha=.65f), RoundedCornerShape(6.dp)).padding(horizontal=6.dp, vertical=3.dp), fontSize = 11.sp)
            }
            Column(Modifier.padding(10.dp)) { Text(asset.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("${asset.width}×${asset.height} · ${formatBytes(asset.sizeBytes)}", color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun EditorScreen(vm: AppViewModel, onBack: () -> Unit, onQueued: () -> Unit) {
    val context = LocalContext.current
    val original = vm.activeProject()
    if (original == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { EmptyCard("Проект не выбран", "Вернись в библиотеку и выбери видео.", Icons.Rounded.MovieCreation, onBack) }
        return
    }
    var project by remember(original.id) { mutableStateOf(original) }
    var error by remember { mutableStateOf<String?>(null) }
    val clips = project.assetIds.mapNotNull { id -> vm.media.firstOrNull { it.id == id } }

    Column(Modifier.fillMaxSize().background(AppBg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.saveProject(project); onBack() }) { Icon(Icons.Rounded.ArrowBack, "Назад") }
            Column(Modifier.weight(1f)) { Text("Монтаж", fontWeight = FontWeight.Black, fontSize = 21.sp); Text("${clips.size} клипов · ${project.ratio}", color = Muted, fontSize = 12.sp) }
            TextButton(onClick = { project = vm.saveProject(project) }) { Text("Сохранить") }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Surface(color = Color(0xFF0F1118), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Таймлайн", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(clips, key = { it.id }) { asset ->
                            Box(Modifier.width(112.dp).height(78.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF232630))) {
                                Thumb(asset.thumbPath, Modifier.fillMaxSize())
                                Text(formatDuration(asset.durationMs), modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).background(Color.Black.copy(alpha=.6f), RoundedCornerShape(5.dp)).padding(horizontal=5.dp, vertical=2.dp), fontSize=10.sp)
                            }
                        }
                    }
                }
            }

            Surface(color = AppCard, shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.AutoAwesome, null, tint = Cyan); Spacer(Modifier.width(8.dp)); Text("Что сделать с видео?", fontWeight = FontWeight.Black, fontSize = 18.sp) }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = project.prompt, onValueChange = { if (it.length <= 6000) project = project.copy(prompt = it) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                        placeholder = { Text("Например: сделай динамичный Reels на 25 секунд, оставь самые сильные моменты, убери паузы, начни с крупного плана…") },
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf(
                            "Reels" to "Сделай динамичный Reels. Убери паузы, начни с сильного хука, используй короткие склейки и крупные субтитры.",
                            "Gaming" to "Сделай энергичный игровой монтаж. Оставь экшен и лучшие моменты, убери ожидание и синхронизируй склейки с ритмом.",
                            "Реклама" to "Сделай рекламный ролик товара: сильный хук, преимущества, крупные планы и короткий призыв к действию.",
                            "Cinematic" to "Собери кинематографичный ролик с более длинными планами, мягким ритмом и атмосферным завершением."
                        )) { preset -> AssistChip(onClick = { project = project.copy(prompt = preset.second) }, label = { Text(preset.first) }) }
                    }
                    if (project.mode == "local") {
                        Spacer(Modifier.height(8.dp))
                        Text("Промпт сохраняется в проекте, но смысловой AI-анализ выполняется только в Cloud AI.", color = Color(0xFFE8CF8B), fontSize = 12.sp)
                    }
                }
            }

            SettingCard("Режим рендера", Icons.Rounded.Tune) {
                ChoiceRow(listOf("cloud" to "Cloud AI", "local" to "На телефоне"), project.mode) { project = project.copy(mode = it) }
                Spacer(Modifier.height(8.dp))
                Text(if (project.mode == "cloud") "AI анализирует смысл сцен, речь, паузы и собирает монтаж на сервере." else "Видео не покидают устройство. Быстрая склейка и кадрирование через Media3.", color = Muted, fontSize = 12.sp)
            }

            SettingCard("Формат", Icons.Rounded.Crop) {
                ChoiceRow(listOf("9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1"), project.ratio) { project = project.copy(ratio = it) }
            }

            if (project.mode == "cloud") {
                SettingCard("AI-стиль", Icons.Rounded.AutoFixHigh) {
                    ChoiceRow(listOf("auto" to "Auto", "gaming" to "Gaming", "dynamic" to "Dynamic", "ad" to "Ads", "cinematic" to "Cinema", "talking" to "Talking"), project.style) { project = project.copy(style = it) }
                }
            }

            SettingCard("Длительность", Icons.Rounded.Timer) {
                Text("${project.durationSec} секунд", fontSize = 24.sp, fontWeight = FontWeight.Black)
                Slider(value = project.durationSec.toFloat(), onValueChange = { project = project.copy(durationSec = (it / 5).toInt() * 5) }, valueRange = 5f..180f, steps = 34)
            }

            SettingCard("Качество", Icons.Rounded.HighQuality) {
                ChoiceRow(listOf("draft" to "Draft", "standard" to "1080p", "high" to "High"), project.quality) { project = project.copy(quality = it) }
                Spacer(Modifier.height(10.dp))
                ChoiceRow(listOf("24" to "24", "30" to "30", "60" to "60 FPS"), project.fps.toString()) { project = project.copy(fps = it.toInt()) }
                if (project.mode == "local") {
                    Spacer(Modifier.height(8.dp))
                    Text("На телефоне FPS — это верхний предел: ролик 24 FPS не превращается искусственно в 60 FPS.", color = Muted, fontSize = 11.sp)
                }
            }

            if (project.mode == "cloud") {
                SettingCard("AI-автоматизация", Icons.Rounded.AutoMode) {
                    ToggleLine("Удалять паузы", project.removePauses) { project = project.copy(removePauses = it) }
                    ToggleLine("Динамические субтитры", project.captions) { project = project.copy(captions = it) }
                    ToggleLine("Склейки в ритм", project.beatSync) { project = project.copy(beatSync = it) }
                }
            } else {
                Surface(color = Color(0xFF151821), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("Локальный режим: последовательная склейка, обрезка по длительности, crop и H.264/AAC экспорт. Для поиска лучших сцен, пауз, субтитров и ритма переключись на Cloud AI.", modifier = Modifier.padding(14.dp), color = Muted, fontSize = 12.sp)
                }
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            Spacer(Modifier.height(96.dp))
        }

        Surface(color = Color(0xFF0D0F14), tonalElevation = 10.dp) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(if (project.mode == "cloud") "Cloud AI" else "На устройстве", fontWeight = FontWeight.Bold); Text("${project.durationSec} сек. · ${project.ratio} · ${project.fps} FPS", color = Muted, fontSize = 12.sp) }
                Button(onClick = {
                    error = null
                    if (clips.isEmpty()) { error = "В проекте нет доступных исходников"; return@Button }
                    if (project.mode == "cloud" && project.prompt.isBlank()) { error = "Для AI-монтажа напиши, какой ролик нужно получить"; return@Button }
                    val saved = vm.saveProject(project)
                    RenderScheduler.enqueue(context, saved.id, cloud = saved.mode == "cloud")
                    onQueued()
                }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 13.dp)) {
                    Icon(if (project.mode == "cloud") Icons.Rounded.CloudUpload else Icons.Rounded.Smartphone, null)
                    Spacer(Modifier.width(8.dp)); Text("Смонтировать", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun ExportsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val wm = remember { WorkManager.getInstance(context) }
    val work by wm.getWorkInfosByTagLiveData(RenderScheduler.TAG_RENDERS).observeAsState(emptyList())
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(work.map { it.state }) { if (work.any { it.state.isFinished }) vm.refresh() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Экспорт", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("Фоновые рендеры и готовые MP4", color = Muted) }
        val active = work.filter { !it.state.isFinished }
        if (active.isNotEmpty()) {
            item { Text("Сейчас рендерится", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            items(active, key = { it.id }) { info ->
                val p = info.progress.getInt("progress", 0)
                val message = info.progress.getString("message") ?: "Подготовка…"
                val projectId = info.tags.firstOrNull { it.startsWith("project:") }?.removePrefix("project:")
                Surface(color = AppCard, shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(Purple.copy(alpha=.2f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AutoAwesome, null, tint = Cyan) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(message, fontWeight = FontWeight.Bold); Text("${p}%", color = Muted) }; IconButton(onClick = { if (projectId != null) RenderScheduler.cancelProject(context, projectId) else wm.cancelWorkById(info.id) }) { Icon(Icons.Rounded.Close, "Отменить") } }
                        Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape))
                    }
                }
            }
        }
        val failed = work.filter { it.state == WorkInfo.State.FAILED }.take(3)
        if (failed.isNotEmpty()) items(failed, key = { "fail-${it.id}" }) { info ->
            val err = info.outputData.getString("error") ?: "Рендер завершился ошибкой"
            Surface(color = Color(0xFF2A171A), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Error, null, tint = MaterialTheme.colorScheme.error); Spacer(Modifier.width(10.dp)); Text(err, fontSize=13.sp, modifier=Modifier.weight(1f)) } }
        }
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Готовые ролики", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f)); Text("${vm.exports.size}", color = Muted) } }
        if (vm.exports.isEmpty()) item { EmptyCard("Готовых роликов пока нет", "После рендера видео появится здесь и останется на устройстве.", Icons.Rounded.FileDownload) }
        else items(vm.exports, key = { it.id }) { record ->
            ExportCard(record, onPlay = { ShareUtils.openVideo(context, File(record.filePath)) }, onShare = { ShareUtils.shareVideo(context, File(record.filePath)) }, onSave = {
                toast = try { ShareUtils.saveToGallery(context, File(record.filePath)); "Сохранено в Movies / AI Video Editor" } catch (e: Exception) { "Не удалось сохранить: ${e.message}" }
            }, onDelete = { vm.deleteExport(record.id) })
        }
        toast?.let { item { Surface(color=AppCard2, shape=RoundedCornerShape(14.dp)) { Text(it, modifier=Modifier.padding(12.dp), color=Cyan, fontSize=13.sp) } } }
        item { Spacer(Modifier.height(60.dp)) }
    }
}

@Composable
private fun ExportCard(record: ExportRecord, onPlay: () -> Unit, onShare: () -> Unit, onSave: () -> Unit, onDelete: () -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(20.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(150.dp).background(Brush.linearGradient(listOf(Color(0xFF24283A), Color(0xFF12141B)))), contentAlignment = Alignment.Center) {
                FilledIconButton(onClick = onPlay, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black), modifier = Modifier.size(58.dp)) { Icon(Icons.Rounded.PlayArrow, "Смотреть", modifier=Modifier.size(32.dp)) }
                Text(if(record.width>0) "${record.width}×${record.height}" else "MP4", modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).background(Color.Black.copy(alpha=.55f), RoundedCornerShape(7.dp)).padding(horizontal=7.dp, vertical=4.dp), fontSize=11.sp)
            }
            Column(Modifier.padding(14.dp)) {
                Text(record.title, fontWeight = FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
                Text(SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(record.createdAt)), color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick=onShare) { Icon(Icons.Rounded.Share, null, modifier=Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Поделиться") }
                    FilledTonalIconButton(onClick=onSave) { Icon(Icons.Rounded.SaveAlt, "В галерею") }
                    Spacer(Modifier.weight(1f)); IconButton(onClick=onDelete) { Icon(Icons.Rounded.DeleteOutline, "Удалить", tint=Muted) }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    var url by remember(vm.serverSettings.baseUrl) { mutableStateOf(vm.serverSettings.baseUrl) }
    var token by remember(vm.serverSettings.apiToken) { mutableStateOf(vm.serverSettings.apiToken) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack) { Icon(Icons.Rounded.ArrowBack,null) }; Text("Настройки", fontSize=26.sp, fontWeight=FontWeight.Black) }
        Spacer(Modifier.height(14.dp))
        Surface(color=AppCard, shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Rounded.Dns,null,tint=Cyan); Spacer(Modifier.width(8.dp)); Text("AI Render Server", fontWeight=FontWeight.Bold, fontSize=18.sp) }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value=url,onValueChange={url=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Адрес сервера")},placeholder={Text("http://192.168.1.50:8000")},shape=RoundedCornerShape(14.dp),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Uri))
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value=token,onValueChange={token=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("API token")},visualTransformation=PasswordVisualTransformation(),shape=RoundedCornerShape(14.dp))
                Spacer(Modifier.height(12.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    Button(onClick={vm.saveServer(url,token)}) { Text("Сохранить") }
                    OutlinedButton(onClick={vm.testServer(url,token)}) { Icon(Icons.Rounded.WifiTethering,null); Spacer(Modifier.width(6.dp)); Text("Проверить") }
                }
                vm.serverTest?.let { Spacer(Modifier.height(10.dp)); Text(it, color=if(it.startsWith("✓")) Success else if(it.startsWith("Ошибка")) MaterialTheme.colorScheme.error else Cyan, fontSize=13.sp) }
            }
        }
        Spacer(Modifier.height(14.dp))
        Surface(color=AppCard, shape=RoundedCornerShape(22.dp)) { Column(Modifier.padding(16.dp)) { Text("Конфиденциальность",fontWeight=FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("В режиме «На телефоне» исходники не отправляются на сервер. Cloud AI загружает только видео выбранного проекта. Токен сервера хранится в Android Keystore в зашифрованном виде.",color=Muted,fontSize=13.sp) } }
        Spacer(Modifier.height(14.dp))
        Surface(color=Color(0xFF251F12), shape=RoundedCornerShape(22.dp)) { Column(Modifier.padding(16.dp)) { Text("Локальный сервер по Wi‑Fi",fontWeight=FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("Для домашней сети можно использовать http://IP_компьютера:8000. Для доступа через интернет обязательно поставь сервер за HTTPS — токен не должен ходить по открытому интернету.",color=Color(0xFFE8CF8B),fontSize=13.sp) } }
    }
}

@Composable
private fun SettingCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Purple); Spacer(Modifier.width(8.dp)); Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp) }; Spacer(Modifier.height(12.dp)); content() }
    }
}

@Composable
private fun ChoiceRow(options: List<Pair<String,String>>, selected: String, onSelected: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { (value,label) -> FilterChip(selected=selected==value,onClick={onSelected(value)},label={Text(label)},leadingIcon=if(selected==value) {{Icon(Icons.Rounded.Check,null,modifier=Modifier.size(16.dp))}} else null) }
    }
}

@Composable
private fun ToggleLine(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) { Text(title,Modifier.weight(1f)); Switch(checked,onCheckedChange=onChange) }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) { Text(title,fontWeight=FontWeight.Black,fontSize=18.sp,modifier=Modifier.weight(1f)); if(action!=null) TextButton(onClick=onAction){Text(action)} }
}

@Composable
private fun EmptyCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: (() -> Unit)? = null) {
    Surface(color=AppCard,shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) { Box(Modifier.size(58.dp).background(Color(0xFF242736),CircleShape),contentAlignment=Alignment.Center){Icon(icon,null,tint=Purple,modifier=Modifier.size(28.dp))}; Spacer(Modifier.height(12.dp)); Text(title,fontWeight=FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(subtitle,color=Muted,fontSize=13.sp); if(onClick!=null){Spacer(Modifier.height(12.dp));OutlinedButton(onClick=onClick){Text("Добавить видео")}} }
    }
}

@Composable
private fun Thumb(path: String?, modifier: Modifier = Modifier) {
    val bitmap = remember(path) { path?.let { BitmapFactory.decodeFile(it) } }
    if (bitmap != null) Image(bitmap.asImageBitmap(), null, modifier=modifier, contentScale=ContentScale.Crop)
    else Box(modifier.background(Color(0xFF242734)), contentAlignment=Alignment.Center) { Icon(Icons.Rounded.Movie,null,tint=Muted) }
}

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0); val m = total / 60; val s = total % 60
    return if (m > 0) "%d:%02d".format(m,s) else "0:%02d".format(s)
}
private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L*1024*1024 -> "%.1f GB".format(bytes.toDouble()/(1024*1024*1024))
    bytes >= 1024L*1024 -> "%.0f MB".format(bytes.toDouble()/(1024*1024))
    else -> "%.0f KB".format(bytes.toDouble()/1024)
}
