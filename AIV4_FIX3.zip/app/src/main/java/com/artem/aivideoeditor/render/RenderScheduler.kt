package com.artem.aivideoeditor.render

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

object RenderScheduler {
    const val KEY_PROJECT_ID = "project_id"
    const val KEY_EXPORT_ID = "export_id"
    const val KEY_OUTPUT_PATH = "output_path"
    const val KEY_STAGE = "stage"
    const val TAG_RENDERS = "video_renders"

    fun enqueue(context: Context, projectId: String, cloud: Boolean): java.util.UUID {
        val data = Data.Builder().putString(KEY_PROJECT_ID, projectId).build()
        val constraints = Constraints.Builder()
            .setRequiresStorageNotLow(true)
            .apply { if (cloud) setRequiredNetworkType(NetworkType.CONNECTED) }
            .build()
        val request = if (cloud) {
            OneTimeWorkRequestBuilder<CloudRenderWorker>()
                .setInputData(data).setConstraints(constraints).addTag(TAG_RENDERS).addTag("project:$projectId").build()
        } else {
            OneTimeWorkRequestBuilder<LocalRenderWorker>()
                .setInputData(data).setConstraints(constraints).addTag(TAG_RENDERS).addTag("project:$projectId").build()
        }
        WorkManager.getInstance(context).enqueueUniqueWork("render:$projectId", ExistingWorkPolicy.REPLACE, request)
        return request.id
    }

    fun cancelProject(context: Context, projectId: String) {
        WorkManager.getInstance(context).cancelUniqueWork("render:$projectId")
    }
}
