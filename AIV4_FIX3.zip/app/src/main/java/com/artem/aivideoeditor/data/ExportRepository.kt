package com.artem.aivideoeditor.data

import android.content.Context
import android.media.MediaMetadataRetriever
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ExportRepository(private val context: Context) {
    val exportDir = File(context.filesDir, "exports").apply { mkdirs() }
    private val index = File(exportDir, "index.json")
    private val lock = Any()

    fun list(): List<ExportRecord> = synchronized(lock) { load().sortedByDescending { it.createdAt } }

    fun newOutputFile(projectId: String): File = File(exportDir, "edit_${projectId}_${System.currentTimeMillis()}.mp4")

    fun register(projectId: String, title: String, file: File): ExportRecord = synchronized(lock) {
        val m = inspect(file)
        val record = ExportRecord(UUID.randomUUID().toString(), projectId, title, file.absolutePath,
            System.currentTimeMillis(), m.first, m.second, m.third)
        val all = load().filter { File(it.filePath).exists() }.toMutableList().apply { add(record) }
        save(all); record
    }

    fun delete(id: String): Boolean = synchronized(lock) {
        val all = load().toMutableList(); val r = all.firstOrNull { it.id == id } ?: return@synchronized false
        File(r.filePath).delete(); all.removeAll { it.id == id }; save(all); true
    }

    private fun inspect(file: File): Triple<Long, Int, Int> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            Triple(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0,
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0,
            )
        } catch (_: Exception) { Triple(0,0,0) } finally { try { r.release() } catch (_: Exception) {} }
    }

    private fun load(): List<ExportRecord> {
        if (!index.exists()) return emptyList()
        return try {
            val a = JSONArray(index.readText()); buildList {
                for (i in 0 until a.length()) a.getJSONObject(i).let { o ->
                    val path = o.getString("filePath"); if (!File(path).exists()) return@let
                    add(ExportRecord(o.getString("id"), o.getString("projectId"), o.optString("title", "Экспорт"),
                        path, o.optLong("createdAt"), o.optLong("durationMs"), o.optInt("width"), o.optInt("height")))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(items: List<ExportRecord>) {
        val a = JSONArray(); items.forEach { r -> a.put(JSONObject().apply {
            put("id",r.id); put("projectId",r.projectId); put("title",r.title); put("filePath",r.filePath)
            put("createdAt",r.createdAt); put("durationMs",r.durationMs); put("width",r.width); put("height",r.height)
        }) }
        index.writeText(a.toString())
    }
}
