package com.artem.aivideoeditor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object ShareUtils {
    fun uriFor(context: Context, file: File): Uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)

    fun shareVideo(context: Context, file: File) {
        val uri = uriFor(context, file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Поделиться видео"))
    }

    fun openVideo(context: Context, file: File) {
        val uri = uriFor(context, file)
        val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        try { context.startActivity(intent) } catch (_: Exception) { shareVideo(context, file) }
    }

    fun saveToGallery(context: Context, file: File): Uri? {
        val name = "AI_Edit_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AI Video Editor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            try {
                resolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { it.copyTo(out, 1024 * 1024) } } ?: error("Не удалось открыть галерею")
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, values, null, null); uri
            } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return null
            val out = File(dir, name); FileInputStream(file).use { i -> FileOutputStream(out).use { i.copyTo(it, 1024 * 1024) } }
            MediaScannerConnection.scanFile(context, arrayOf(out.absolutePath), arrayOf("video/mp4"), null)
            Uri.fromFile(out)
        }
    }
}
