package com.artem.aivideoeditor.render

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.artem.aivideoeditor.VideoEditorApp
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

@UnstableApi
class LocalRenderWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    private val transformerRef = AtomicReference<Transformer?>()
    private val main = Handler(Looper.getMainLooper())

    override fun doWork(): Result {
        val app = applicationContext as VideoEditorApp
        val projectId = inputData.getString(RenderScheduler.KEY_PROJECT_ID) ?: return Result.failure()
        val project = app.projects.get(projectId) ?: return Result.failure(error("Проект не найден"))
        val assets = project.assetIds.mapNotNull(app.library::find)
        if (assets.isEmpty()) return Result.failure(error("Исходники проекта удалены"))
        val output = app.exports.newOutputFile(projectId)
        val latch = CountDownLatch(1)
        val failure = AtomicReference<Throwable?>(null)
        val progressValue = AtomicInteger(0)

        try {
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Локальный монтаж", "Подготовка…", 0, mediaProcessing = true)).get()
            val edited = buildEditedItems(project.ratio, project.durationSec, project.quality, project.fps, assets)
            val sequence = EditedMediaItemSequence.withAudioAndVideoFrom(edited)
            val composition = Composition.Builder(sequence).build()

            main.post {
                try {
                    val targetBitrate = when (project.quality.lowercase()) {
                        "draft" -> 4_500_000
                        "high" -> 14_000_000
                        else -> 8_500_000
                    }
                    val encoderFactory = DefaultEncoderFactory.Builder(applicationContext)
                        .setRequestedVideoEncoderSettings(
                            VideoEncoderSettings.Builder().setBitrate(targetBitrate).build()
                        ).build()
                    val transformer = Transformer.Builder(applicationContext)
                        .setLooper(Looper.getMainLooper())
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .setEncoderFactory(encoderFactory)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) { latch.countDown() }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                failure.set(exportException); latch.countDown()
                            }
                        }).build()
                    transformerRef.set(transformer)
                    transformer.start(composition, output.absolutePath)
                } catch (t: Throwable) { failure.set(t); latch.countDown() }
            }

            val holder = ProgressHolder()
            while (!latch.await(650, TimeUnit.MILLISECONDS)) {
                if (isStopped) {
                    main.post { try { transformerRef.get()?.cancel() } catch (_: Exception) {} }
                    output.delete(); return Result.failure(error("Отменено"))
                }
                main.post {
                    try {
                        val t = transformerRef.get() ?: return@post
                        if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) progressValue.set(holder.progress)
                    } catch (_: Exception) {}
                }
                val p = progressValue.get().coerceIn(0,99)
                setProgressAsync(progress(p, "local_render", "Рендер на устройстве ${p}%")).get()
                setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Локальный монтаж", "Рендер ${p}%", p, mediaProcessing = true)).get()
            }
            failure.get()?.let { throw it }
            if (!output.exists() || output.length() < 1024) throw IllegalStateException("Media3 не создал корректный MP4")
            val record = app.exports.register(projectId, project.title, output)
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Готово", "Локальный MP4 создан", 100, mediaProcessing = true)).get()
            return Result.success(Data.Builder().putString(RenderScheduler.KEY_EXPORT_ID, record.id)
                .putString(RenderScheduler.KEY_OUTPUT_PATH, record.filePath).build())
        } catch (t: Throwable) {
            output.delete(); return Result.failure(error(t.message ?: t.javaClass.simpleName))
        } finally { transformerRef.set(null) }
    }

    override fun onStopped() {
        main.post { try { transformerRef.get()?.cancel() } catch (_: Exception) {} }
        super.onStopped()
    }

    private fun buildEditedItems(ratio: String, targetSec: Int, quality: String, fps: Int, assets: List<com.artem.aivideoeditor.data.MediaAsset>): List<EditedMediaItem> {
        val targetMs = targetSec.coerceIn(3,180) * 1000L
        val per = (targetMs / assets.size.coerceAtLeast(1)).coerceAtLeast(900L)
        val longEdge = if (quality.lowercase() == "draft") 1280 else 1920
        val shortEdge = if (quality.lowercase() == "draft") 720 else 1080
        val square = if (quality.lowercase() == "draft") 720 else 1080
        val (w,h) = when (ratio) { "16:9" -> longEdge to shortEdge; "1:1" -> square to square; else -> shortEdge to longEdge }
        val effect = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        return assets.map { asset ->
            val end = minOf(asset.durationMs.takeIf { it > 0 } ?: per, per)
            val media = MediaItem.Builder().setUri(Uri.fromFile(File(asset.filePath)))
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0).setEndPositionMs(end).build())
                .build()
            EditedMediaItem.Builder(media).setFlattenForSlowMotion(true)
                // For video inputs this is a safe maximum FPS: high-FPS sources are reduced,
                // while low-FPS sources are not duplicated artificially.
                .setFrameRate(fps.coerceIn(24, 60))
                .setEffects(Effects(emptyList(), listOf(effect))).build()
        }
    }

    private fun progress(value: Int, stage: String, message: String) = Data.Builder().putInt("progress", value)
        .putString(RenderScheduler.KEY_STAGE, stage).putString("message", message).build()
    private fun error(message: String) = Data.Builder().putString("error", message.take(1500)).build()
}
