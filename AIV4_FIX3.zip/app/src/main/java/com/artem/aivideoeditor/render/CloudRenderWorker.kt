package com.artem.aivideoeditor.render

import android.content.Context
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.artem.aivideoeditor.VideoEditorApp
import com.artem.aivideoeditor.network.CloudApi
import java.io.IOException

class CloudRenderWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val app = applicationContext as VideoEditorApp
        val projectId = inputData.getString(RenderScheduler.KEY_PROJECT_ID) ?: return Result.failure()
        val project = app.projects.get(projectId) ?: return Result.failure(error("Проект не найден"))
        val assets = project.assetIds.mapNotNull(app.library::find)
        if (assets.isEmpty()) return Result.failure(error("Исходники проекта удалены"))
        val settings = app.settings.load()
        if (settings.baseUrl.isBlank()) return Result.failure(error("Сервер не настроен"))
        val api = CloudApi(settings)
        var jobId: String? = null
        try {
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "AI-монтаж", "Загрузка исходников…", 2)).get()
            setProgressAsync(progress(2, "upload", "Загрузка исходников…")).get()
            jobId = api.createJob(project, assets)
            var consecutiveNetworkErrors = 0
            while (!isStopped) {
                val status = try {
                    api.job(jobId).also { consecutiveNetworkErrors = 0 }
                } catch (e: IOException) {
                    consecutiveNetworkErrors++
                    if (consecutiveNetworkErrors >= 6) throw e
                    Thread.sleep(2500); continue
                }
                val mapped = (8 + status.progress * 0.82).toInt().coerceIn(8, 90)
                setProgressAsync(progress(mapped, status.stage, status.message)).get()
                setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "AI-монтаж", status.message.ifBlank { status.stage }, mapped)).get()
                when (status.status) {
                    "done" -> break
                    "failed" -> throw IllegalStateException(status.error ?: "Ошибка серверного рендера")
                    "cancelled" -> return Result.failure(error("Рендер отменён"))
                }
                Thread.sleep(1800)
            }
            if (isStopped) {
                jobId?.let { try { api.cancel(it) } catch (_: Exception) {} }
                return Result.failure(error("Отменено"))
            }
            val output = app.exports.newOutputFile(projectId)
            setProgressAsync(progress(91, "download", "Скачиваем готовое видео…")).get()
            api.download(jobId, output) { p ->
                val overall = 91 + (p * 8 / 100)
                setProgressAsync(progress(overall, "download", "Скачивание ${p}%")).get()
            }
            val record = app.exports.register(projectId, project.title, output)
            api.delete(jobId)
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Готово", "Видео сохранено в приложении", 100)).get()
            return Result.success(Data.Builder()
                .putString(RenderScheduler.KEY_EXPORT_ID, record.id)
                .putString(RenderScheduler.KEY_OUTPUT_PATH, record.filePath).build())
        } catch (e: Exception) {
            if (isStopped && jobId != null) try { api.cancel(jobId) } catch (_: Exception) {}
            return if (jobId == null && runAttemptCount < 2 && e is IOException) Result.retry()
            else Result.failure(error(e.message ?: e.javaClass.simpleName))
        }
    }

    override fun onStopped() { super.onStopped() }

    private fun progress(value: Int, stage: String, message: String) = Data.Builder()
        .putInt("progress", value.coerceIn(0,100)).putString(RenderScheduler.KEY_STAGE, stage).putString("message", message).build()
    private fun error(message: String) = Data.Builder().putString("error", message.take(1500)).build()
}
