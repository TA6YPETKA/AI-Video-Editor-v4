package com.artem.aivideoeditor

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.artem.aivideoeditor.data.EditProject
import com.artem.aivideoeditor.data.ExportRecord
import com.artem.aivideoeditor.data.MediaAsset
import com.artem.aivideoeditor.data.ServerSettings
import com.artem.aivideoeditor.network.CloudApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VideoEditorApp

    var media by mutableStateOf<List<MediaAsset>>(emptyList()); private set
    var projects by mutableStateOf<List<EditProject>>(emptyList()); private set
    var exports by mutableStateOf<List<ExportRecord>>(emptyList()); private set
    var importing by mutableStateOf(false); private set
    var importMessage by mutableStateOf<String?>(null); private set
    var activeProjectId by mutableStateOf<String?>(null)
    var serverSettings by mutableStateOf(app.settings.load()); private set
    var serverTest by mutableStateOf<String?>(null); private set

    init { refresh() }

    fun refresh() {
        media = app.library.list(); projects = app.projects.list(); exports = app.exports.list(); serverSettings = app.settings.load()
    }

    fun importVideos(uris: List<Uri>) {
        if (uris.isEmpty() || importing) return
        importing = true; importMessage = null
        viewModelScope.launch {
            try {
                val added = withContext(Dispatchers.IO) { app.library.importUris(uris) }
                refresh()
                importMessage = if (added.isEmpty()) "Новых видео не добавлено — возможно, они уже в библиотеке" else "Добавлено видео: ${added.size}"
            } catch (e: Exception) { importMessage = e.message ?: "Ошибка импорта" }
            finally { importing = false }
        }
    }

    fun toggleFavorite(id: String) { viewModelScope.launch(Dispatchers.IO) { app.library.toggleFavorite(id); withContext(Dispatchers.Main) { refresh() } } }
    fun deleteMedia(id: String) { viewModelScope.launch(Dispatchers.IO) { app.library.delete(id); withContext(Dispatchers.Main) { refresh() } } }
    fun deleteExport(id: String) { viewModelScope.launch(Dispatchers.IO) { app.exports.delete(id); withContext(Dispatchers.Main) { refresh() } } }

    fun createProject(assetIds: List<String>): EditProject {
        val p = app.projects.create(assetIds)
        activeProjectId = p.id; refresh(); return p
    }

    fun activeProject(): EditProject? = activeProjectId?.let(app.projects::get)

    fun saveProject(project: EditProject): EditProject {
        val p = app.projects.saveProject(project); activeProjectId = p.id; refresh(); return p
    }

    fun openProject(id: String) { activeProjectId = id }
    fun deleteProject(id: String) { app.projects.delete(id); if (activeProjectId == id) activeProjectId = null; refresh() }

    fun saveServer(baseUrl: String, token: String) {
        app.settings.save(baseUrl, token); serverSettings = app.settings.load(); serverTest = null
    }

    fun testServer(baseUrl: String, token: String) {
        saveServer(baseUrl, token); serverTest = "Проверяем…"
        viewModelScope.launch {
            serverTest = try {
                val result = withContext(Dispatchers.IO) { CloudApi(ServerSettings(baseUrl.trim().trimEnd('/'), token.trim())).health() }
                if (result.optBoolean("ok")) "✓ Сервер готов · FFmpeg: ${result.optBoolean("ffmpeg")}" else "Сервер отвечает, но FFmpeg недоступен"
            } catch (e: Exception) { "Ошибка: ${e.message}" }
        }
    }
}
