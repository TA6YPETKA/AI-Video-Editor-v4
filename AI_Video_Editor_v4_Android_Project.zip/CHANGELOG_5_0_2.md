# PITLINE 5.0.2

- Tap on empty space clears focus so the on-screen keyboard closes.
- Projects can be renamed from the editor header.
- New projects get a suggested title from the first imported clip instead of always "Новый проект".
- The top-right Settings button on Home now opens Settings.
- Added app-level defaults for new projects: resolution, FPS, codec, aspect ratio, duration, and autosave.
- Added H.264/AVC and H.265/HEVC selection. HEVC is only selectable when the device exposes an encoder; render falls back to H.264 if needed.
- Added 720p / 1080p / 1440p local output presets.
- Existing local-render fix for clipped media remains in place (slow-motion flattening disabled for clipped segments).
