# PITLINE v5

Local-first Android video editor.

## Main flow
1. Import clips.
2. Create a project.
3. Describe the desired edit in a prompt and choose a style.
4. Tap **СМОНТИРОВАТЬ**.
5. Media3 renders locally on the phone to H.264/AAC MP4.

The main render flow does **not** require a server. Cloud settings are optional and reserved for future heavy AI features.
