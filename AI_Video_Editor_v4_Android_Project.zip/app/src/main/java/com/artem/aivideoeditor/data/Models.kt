package com.artem.aivideoeditor.data

data class MediaAsset(
    val id: String,
    val name: String,
    val filePath: String,
    val thumbPath: String?,
    val sha256: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val createdAt: Long,
    val favorite: Boolean = false,
)

data class EditProject(
    val id: String,
    val title: String,
    val assetIds: List<String>,
    val prompt: String,
    val ratio: String = "9:16",
    val durationSec: Int = 30,
    val style: String = "auto",
    val quality: String = "standard",
    val fps: Int = 30,
    val codec: String = "h264",
    val mode: String = "local",
    val removePauses: Boolean = true,
    val captions: Boolean = true,
    val beatSync: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long,
)

data class ExportRecord(
    val id: String,
    val projectId: String,
    val title: String,
    val filePath: String,
    val createdAt: Long,
    val durationMs: Long = 0,
    val width: Int = 0,
    val height: Int = 0,
)

data class AppSettings(
    val defaultQuality: String = "standard",
    val defaultFps: Int = 30,
    val defaultCodec: String = "h264",
    val defaultRatio: String = "9:16",
    val defaultDurationSec: Int = 30,
    val autoSaveProjects: Boolean = true,
)

data class ServerSettings(
    val baseUrl: String = "",
    val apiToken: String = "",
)

data class CloudJobStatus(
    val id: String,
    val status: String,
    val progress: Int,
    val stage: String,
    val message: String,
    val error: String? = null,
    val downloadUrl: String? = null,
)
