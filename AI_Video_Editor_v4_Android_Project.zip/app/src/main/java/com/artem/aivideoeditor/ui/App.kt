package com.artem.aivideoeditor.ui

import android.graphics.BitmapFactory
import android.media.MediaCodecList
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.artem.aivideoeditor.AppViewModel
import com.artem.aivideoeditor.ShareUtils
import com.artem.aivideoeditor.data.AppSettings
import com.artem.aivideoeditor.data.ExportRecord
import com.artem.aivideoeditor.data.MediaAsset
import com.artem.aivideoeditor.render.RenderScheduler
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private enum class Screen { Home, Library, Editor, Exports, Settings }

@Composable
fun VideoEditorRoot(incomingUris: List<Uri>, consumeIncoming: () -> Unit, vm: AppViewModel = viewModel()) {
    AIVideoEditorTheme {
        val context = LocalContext.current
        val focusManager = LocalFocusManager.current
        var screenName by rememberSaveable { mutableStateOf(Screen.Home.name) }
        val screen = runCatching { Screen.valueOf(screenName) }.getOrDefault(Screen.Home)
        val selected = remember { mutableStateListOf<String>() }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.importVideos(uris)
        }

        LaunchedEffect(incomingUris) {
            if (incomingUris.isNotEmpty()) {
                vm.importVideos(incomingUris); screenName = Screen.Library.name; consumeIncoming()
            }
        }

        Scaffold(
            containerColor = AppBg,
            bottomBar = {
                if (screen != Screen.Editor && screen != Screen.Settings) {
                    NavigationBar(containerColor = Color(0xFF08090B), tonalElevation = 0.dp) {
                        BottomItem(screen == Screen.Home, Icons.Rounded.Home, "Главная") { screenName = Screen.Home.name }
                        BottomItem(screen == Screen.Library, Icons.Rounded.VideoLibrary, "Библиотека") { screenName = Screen.Library.name }
                        NavigationBarItem(
                            selected = false,
                            onClick = {
                                val ids = selected.toList().ifEmpty { vm.media.take(1).map { it.id } }
                                if (ids.isNotEmpty()) { vm.createProject(ids); screenName = Screen.Editor.name }
                                else { picker.launch(arrayOf("video/*")); screenName = Screen.Library.name }
                            },
                            icon = { Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(RacingRed, RacingOrange)), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, null, tint = Color.White) } },
                            label = { Text("Создать", fontSize = 11.sp) }
                        )
                        BottomItem(screen == Screen.Exports, Icons.Rounded.FileDownload, "Экспорт") { vm.refresh(); screenName = Screen.Exports.name }
                        BottomItem(false, Icons.Rounded.Settings, "Настройки") { screenName = Screen.Settings.name }
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).pointerInput(Unit) {
                    detectTapGestures {
                        focusManager.clearFocus()
                    }
                }
            ) {
                when (screen) {
                    Screen.Home -> HomeScreen(vm, onNew = {
                        val ids = selected.toList().ifEmpty { vm.media.take(1).map { it.id } }
                        if (ids.isEmpty()) { picker.launch(arrayOf("video/*")); screenName = Screen.Library.name }
                        else { vm.createProject(ids); screenName = Screen.Editor.name }
                    }, onOpenProject = { vm.openProject(it); screenName = Screen.Editor.name }, onLibrary = { screenName = Screen.Library.name }, onSettings = { screenName = Screen.Settings.name })
                    Screen.Library -> LibraryScreen(vm, selected, onImport = { picker.launch(arrayOf("video/*")) }, onCreate = {
                        if (selected.isNotEmpty()) { vm.createProject(selected.toList()); selected.clear(); screenName = Screen.Editor.name }
                    })
                    Screen.Editor -> EditorScreen(vm, onBack = { screenName = Screen.Home.name }, onQueued = { vm.refresh(); screenName = Screen.Exports.name })
                    Screen.Exports -> ExportsScreen(vm)
                    Screen.Settings -> SettingsScreen(vm, onBack = { screenName = Screen.Home.name })
                }
            }
        }
    }
}

@Composable
private fun RowScope.BottomItem(selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, label) },
        label = { Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = RacingRed,
            indicatorColor = RacingRed.copy(alpha = .18f),
            unselectedIconColor = Muted,
            unselectedTextColor = Muted,
        )
    )
}

@Composable
private fun HomeScreen(vm: AppViewModel, onNew: () -> Unit, onOpenProject: (String) -> Unit, onLibrary: () -> Unit, onSettings: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PITLINE", color = RacingRed, fontWeight = FontWeight.Black, fontSize = 32.sp, letterSpacing = (-1).sp)
                    Text("B O R N   T O   C R E A T E", color = Color(0xFFB7BAC1), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
                Surface(onClick = onSettings, shape = RoundedCornerShape(12.dp), color = AppCard2) {
                    Icon(Icons.Rounded.Settings, "Настройки", tint = TrackWhite, modifier = Modifier.padding(11.dp))
                }
            }
        }

        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF090A0C), Color(0xFF15100F), Color(0xFF2B0C08))))
                    .border(1.dp, Color(0xFF2E3037), RoundedCornerShape(8.dp))
                    .clickable { onNew() }
                    .padding(20.dp)
            ) {
                Box(Modifier.align(Alignment.CenterEnd).width(34.dp).height(210.dp).background(RacingRed.copy(alpha=.92f)))
                Box(Modifier.align(Alignment.CenterEnd).width(118.dp).height(34.dp).background(RacingRed.copy(alpha=.92f)))
                Column(Modifier.fillMaxWidth()) {
                    Text("LOCAL AI EDITOR", color = RacingOrange, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(14.dp))
                    Text("IDEAS", fontSize = 31.sp, fontWeight = FontWeight.Black, lineHeight = 30.sp)
                    Text("INTO", fontSize = 31.sp, fontWeight = FontWeight.Black, lineHeight = 30.sp)
                    Text("POWERFUL", color = RacingRed, fontSize = 31.sp, fontWeight = FontWeight.Black, lineHeight = 30.sp)
                    Text("VIDEOS", fontSize = 31.sp, fontWeight = FontWeight.Black, lineHeight = 30.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Загрузи видео. Опиши результат.\nМонтаж и экспорт — прямо на телефоне.", color = Color(0xFFC0C3CA), fontSize = 13.sp, lineHeight = 18.sp)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = onNew,
                        colors = ButtonDefaults.buttonColors(containerColor = RacingRed, contentColor = Color.White),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
                    ) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("СОЗДАТЬ ПРОЕКТ", fontWeight = FontWeight.Black, letterSpacing = .5.sp)
                        Spacer(Modifier.width(12.dp))
                        Icon(Icons.Rounded.ChevronRight, null)
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf(
                    Triple("АВТОМОНТАЖ", "По твоему промпту", Icons.Rounded.AutoAwesome),
                    Triple("REELS / TIKTOK", "9:16", Icons.Rounded.Smartphone),
                    Triple("YOUTUBE SHORTS", "Динамичный монтаж", Icons.Rounded.PlayArrow)
                )) { preset ->
                    Surface(
                        onClick = onNew,
                        color = AppCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.width(158.dp).border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Icon(preset.third, null, tint = RacingRed, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.height(18.dp))
                            Text(preset.first, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text(preset.second, color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("${vm.media.size}", "КЛИПОВ", Icons.Rounded.VideoLibrary, Modifier.weight(1f))
                StatCard("${vm.exports.size}", "ГОТОВО", Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
        }

        item { SectionTitle("ПОСЛЕДНИЕ ПРОЕКТЫ", "Все видео") { onLibrary() } }
        if (vm.projects.isEmpty()) item { EmptyCard("Проектов пока нет", "Добавь видео и создай первый локальный монтаж.", Icons.Rounded.MovieCreation) }
        else items(vm.projects.take(6), key = { it.id }) { p ->
            Surface(
                onClick = { onOpenProject(p.id) },
                color = AppCard,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(5.dp).height(52.dp).background(RacingRed, RoundedCornerShape(2.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.title.uppercase(), fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text("${p.assetIds.size} клипов  •  ${p.ratio}  •  ${p.durationSec} сек.", color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = RacingRed)
                }
            }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
}

@Composable
private fun StatCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = AppCard, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Cyan); Spacer(Modifier.height(14.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Black); Text(label, color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun LibraryScreen(vm: AppViewModel, selected: MutableList<String>, onImport: () -> Unit, onCreate: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<MediaAsset?>(null) }
    val list = vm.media.filter { (!favoritesOnly || it.favorite) && (query.isBlank() || it.name.contains(query, true)) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("БИБЛИОТЕКА", fontSize = 26.sp, fontWeight = FontWeight.Black); Text("LOCAL MEDIA • видео остаются на устройстве", color = RacingRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp) }
            FilledTonalIconButton(onClick = onImport) { Icon(Icons.Rounded.Add, "Импорт") }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Поиск видео") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = !favoritesOnly }, label = { Text("Избранное") }, leadingIcon = { Icon(Icons.Rounded.Favorite, null, modifier = Modifier.size(18.dp)) })
            Spacer(Modifier.weight(1f)); Text("${list.size} видео", color = Muted, fontSize = 13.sp)
        }
        if (vm.importing) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.importMessage?.let { Text(it, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { EmptyCard("Библиотека пуста", "Импортируй видео из галереи или поделись роликом в это приложение.", Icons.Rounded.VideoLibrary, onImport) }
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 100.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                gridItems(list, key = { it.id }) { asset -> MediaTile(asset, selected.contains(asset.id), onToggle = {
                    if (selected.contains(asset.id)) selected.remove(asset.id) else selected.add(asset.id)
                }, onFavorite = { vm.toggleFavorite(asset.id) }, onDelete = { pendingDelete = asset }) }
            }
        }
        pendingDelete?.let { asset ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text("Удалить из библиотеки?") },
                text = { Text("${asset.name} будет удалён из хранилища приложения. Проекты, где он использовался, потеряют этот исходник.") },
                confirmButton = { TextButton(onClick = { selected.remove(asset.id); vm.deleteMedia(asset.id); pendingDelete = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) } },
                dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Отмена") } }
            )
        }
        AnimatedVisibility(selected.isNotEmpty()) {
            Surface(color = Color(0xFF1B1D27), shape = RoundedCornerShape(20.dp), tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Выбрано: ${selected.size}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Button(onClick = onCreate) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("СОЗДАТЬ") }
                }
            }
        }
    }
}

@Composable
private fun MediaTile(asset: MediaAsset, selected: Boolean, onToggle: () -> Unit, onFavorite: () -> Unit, onDelete: () -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(if (selected) 2.dp else 0.dp, if (selected) Purple else Color.Transparent, RoundedCornerShape(18.dp)).clickable { onToggle() }) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF20232D))) {
                Thumb(asset.thumbPath, Modifier.fillMaxSize())
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(8.dp), color = Color.Black.copy(alpha=.48f), shape = CircleShape) {
                    IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) { Icon(if (asset.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if(asset.favorite) Pink else Color.White, modifier = Modifier.size(18.dp)) }
                }
                if (selected) Box(Modifier.align(Alignment.TopStart).padding(8.dp).size(28.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Check, null, modifier = Modifier.size(18.dp)) }
                Surface(modifier = Modifier.align(Alignment.BottomStart).padding(7.dp), color = Color.Black.copy(alpha=.48f), shape = CircleShape) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) { Icon(Icons.Rounded.DeleteOutline, "Удалить из библиотеки", tint = Color.White, modifier = Modifier.size(17.dp)) }
                }
                Text(formatDuration(asset.durationMs), modifier = Modifier.align(Alignment.BottomEnd).padding(7.dp).background(Color.Black.copy(alpha=.65f), RoundedCornerShape(6.dp)).padding(horizontal=6.dp, vertical=3.dp), fontSize = 11.sp)
            }
            Column(Modifier.padding(10.dp)) { Text(asset.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("${asset.width}×${asset.height} · ${formatBytes(asset.sizeBytes)}", color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun EditorScreen(vm: AppViewModel, onBack: () -> Unit, onQueued: () -> Unit) {
    val context = LocalContext.current
    val original = vm.activeProject()
    if (original == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { EmptyCard("Проект не выбран", "Вернись в библиотеку и выбери видео.", Icons.Rounded.MovieCreation, onBack) }
        return
    }
    var project by remember(original.id) { mutableStateOf(original.copy(mode = "local")) }
    var error by remember { mutableStateOf<String?>(null) }
    var renameOpen by remember { mutableStateOf(false) }
    var renameText by remember(project.title) { mutableStateOf(project.title) }
    val hevcSupported = remember { hasVideoEncoder("video/hevc") }
    val clips = project.assetIds.mapNotNull { id -> vm.media.firstOrNull { it.id == id } }

    LaunchedEffect(project, vm.appSettings.autoSaveProjects) {
        if (vm.appSettings.autoSaveProjects) {
            delay(650)
            vm.saveProject(project.copy(mode = "local"))
        }
    }

    Column(Modifier.fillMaxSize().background(AppBg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.saveProject(project.copy(mode = "local")); onBack() }) { Icon(Icons.Rounded.ArrowBack, "Назад") }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(project.title.uppercase(), fontWeight = FontWeight.Black, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    IconButton(onClick = { renameText = project.title; renameOpen = true }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Rounded.Edit, "Переименовать проект", tint = RacingRed, modifier = Modifier.size(18.dp))
                    }
                }
                Text("LOCAL EDIT  •  ${clips.size} CLIPS", color = RacingRed, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
            }
            TextButton(onClick = { project = vm.saveProject(project.copy(mode = "local")) }) { Text("Сохранить", color = TrackWhite) }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(color = AppCard, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))) {
                Column(Modifier.padding(14.dp)) {
                    PitlineSectionHeader("ИСХОДНИКИ", "${clips.size} клипов")
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(clips, key = { it.id }) { asset ->
                            Box(Modifier.width(106.dp).height(74.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF232630))) {
                                Thumb(asset.thumbPath, Modifier.fillMaxSize())
                                Text(formatDuration(asset.durationMs), modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).background(Color.Black.copy(alpha=.72f), RoundedCornerShape(4.dp)).padding(horizontal=5.dp, vertical=2.dp), fontSize=9.sp)
                            }
                        }
                    }
                }
            }

            Surface(color = AppCard, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))) {
                Column(Modifier.padding(14.dp)) {
                    PitlineSectionHeader("ПРОМПТ ДЛЯ МОНТАЖА", "LOCAL")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = project.prompt,
                        onValueChange = { if (it.length <= 6000) project = project.copy(prompt = it) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 128.dp),
                        placeholder = { Text("Например: сделай динамичный Reels на 30 секунд, короткие склейки, начни с сильного момента…") },
                        shape = RoundedCornerShape(6.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RacingRed,
                            unfocusedBorderColor = Color(0xFF343740),
                            focusedContainerColor = Color(0xFF0A0B0E),
                            unfocusedContainerColor = Color(0xFF0A0B0E)
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(listOf(
                            "Динамичный" to "Сделай динамичный ролик: короткие планы, быстрый темп, сильное начало.",
                            "Gaming" to "Сделай энергичный игровой монтаж с короткими склейками и быстрым темпом.",
                            "Реклама" to "Собери короткий рекламный ролик: быстрый хук, продукт в центре, уверенный темп.",
                            "Cinematic" to "Сделай кинематографичный ролик: более длинные планы, спокойный ритм и атмосферный финал."
                        )) { preset ->
                            AssistChip(onClick = { project = project.copy(prompt = preset.second) }, label = { Text(preset.first) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Промпт влияет на темп и длину склеек. Видео не отправляется в облако.", color = Color(0xFFB7BAC1), fontSize = 11.sp)
                }
            }

            SettingCard("СТИЛЬ МОНТАЖА", Icons.Rounded.AutoFixHigh) {
                ChoiceRow(
                    listOf("auto" to "Auto", "dynamic" to "Dynamic", "gaming" to "Gaming", "ad" to "Ads", "cinematic" to "Cinema", "talking" to "Vlog"),
                    project.style
                ) { project = project.copy(style = it) }
            }

            SettingCard("ФОРМАТ", Icons.Rounded.Crop) {
                ChoiceRow(listOf("9:16" to "9:16 Reels", "16:9" to "16:9 YouTube", "1:1" to "1:1"), project.ratio) { project = project.copy(ratio = it) }
            }

            SettingCard("ДЛИТЕЛЬНОСТЬ", Icons.Rounded.Timer) {
                Text("${project.durationSec} СЕК", fontSize = 27.sp, fontWeight = FontWeight.Black)
                Slider(
                    value = project.durationSec.toFloat(),
                    onValueChange = { project = project.copy(durationSec = ((it / 5).toInt() * 5).coerceAtLeast(5)) },
                    valueRange = 5f..180f,
                    steps = 34,
                    colors = SliderDefaults.colors(thumbColor = RacingRed, activeTrackColor = RacingRed)
                )
            }

            SettingCard("КАЧЕСТВО И КОДЕК", Icons.Rounded.HighQuality) {
                Text("РАЗРЕШЕНИЕ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                Spacer(Modifier.height(6.dp))
                ChoiceRow(listOf("draft" to "720p", "standard" to "1080p", "high" to "1440p"), project.quality) { project = project.copy(quality = it) }
                Spacer(Modifier.height(11.dp))
                Text("ЧАСТОТА КАДРОВ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                Spacer(Modifier.height(6.dp))
                ChoiceRow(listOf("24" to "24", "30" to "30", "60" to "60 FPS"), project.fps.toString()) { project = project.copy(fps = it.toInt()) }
                Spacer(Modifier.height(11.dp))
                Text("ВИДЕОКОДЕК", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                Spacer(Modifier.height(6.dp))
                CodecChoiceRow(project.codec, hevcSupported) { project = project.copy(codec = it) }
                Spacer(Modifier.height(6.dp))
                Text(if (project.codec == "h265") "H.265 даёт меньший файл при похожем качестве. На старых устройствах совместимость ниже." else "H.264 — максимальная совместимость с телефонами, соцсетями и видеоредакторами.", color = Muted, fontSize = 10.sp)
            }

            Surface(
                color = Color(0xFF160C0A),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, RacingRed.copy(alpha=.45f), RoundedCornerShape(8.dp))
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(RacingRed, RoundedCornerShape(5.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Smartphone, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("LOCAL ENGINE", color = RacingRed, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 1.sp)
                        Text("Бесплатно • без сервера • MP4 ${if (project.codec == "h265") "H.265" else "H.264"}/AAC", color = TrackWhite, fontSize = 12.sp)
                    }
                }
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            Spacer(Modifier.height(94.dp))
        }

        Surface(color = Color(0xFF08090B), tonalElevation = 12.dp) {
            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Button(
                    onClick = {
                        error = null
                        if (clips.isEmpty()) { error = "В проекте нет доступных исходников"; return@Button }
                        val saved = vm.saveProject(project.copy(mode = "local"))
                        RenderScheduler.enqueue(context, saved.id, cloud = false)
                        onQueued()
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RacingRed, contentColor = Color.White),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("СМОНТИРОВАТЬ", fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = .6.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.ChevronRight, null)
                }
                Text("Локальная обработка • бесплатно • без ограничений", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 5.dp))
            }
        }
    }

    if (renameOpen) {
        AlertDialog(
            onDismissRequest = { renameOpen = false },
            title = { Text("Переименовать проект") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { if (it.length <= 80) renameText = it },
                    singleLine = true,
                    label = { Text("Название") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = renameText.trim().ifBlank { "Новый проект" }
                    project = vm.saveProject(project.copy(title = clean, mode = "local"))
                    renameOpen = false
                }) { Text("Сохранить", color = RacingRed) }
            },
            dismissButton = { TextButton(onClick = { renameOpen = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun ExportsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val wm = remember { WorkManager.getInstance(context) }
    val work by wm.getWorkInfosByTagLiveData(RenderScheduler.TAG_RENDERS).observeAsState(emptyList())
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(work.map { it.state }) { if (work.any { it.state.isFinished }) vm.refresh() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Text("EXPORT", color = RacingRed, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("ГОТОВЫЕ РОЛИКИ", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Локальные рендеры и MP4 на устройстве", color = Muted, fontSize = 12.sp)
        }

        val active = work.filter { !it.state.isFinished }
        if (active.isNotEmpty()) {
            items(active, key = { it.id }) { info ->
                val p = info.progress.getInt("progress", 0)
                val message = info.progress.getString("message") ?: "Подготовка…"
                val projectId = info.tags.firstOrNull { it.startsWith("project:") }?.removePrefix("project:")
                Surface(
                    color = AppCard,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF30333A), RoundedCornerShape(8.dp))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text("ИДЁТ МОНТАЖ…", fontWeight = FontWeight.Black, fontSize = 17.sp)
                                Text(message, color = Muted, fontSize = 12.sp)
                            }
                            Text("$p%", color = RacingRed, fontWeight = FontWeight.Black, fontSize = 32.sp)
                        }
                        Spacer(Modifier.height(15.dp))
                        LinearProgressIndicator(
                            progress = { p / 100f },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(2.dp)),
                            color = RacingRed,
                            trackColor = Color(0xFF2A2D33)
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Smartphone, null, tint = RacingOrange, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Рендер выполняется на телефоне", color = Color(0xFFB7BAC1), fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { if (projectId != null) RenderScheduler.cancelProject(context, projectId) else wm.cancelWorkById(info.id) }) { Text("Отменить") }
                        }
                    }
                }
            }
        }

        val failed = work.filter { it.state == WorkInfo.State.FAILED }.take(3)
        if (failed.isNotEmpty()) items(failed, key = { "fail-${it.id}" }) { info ->
            val err = info.outputData.getString("error") ?: "Рендер завершился ошибкой"
            Surface(color = Color(0xFF2A1111), shape = RoundedCornerShape(8.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Error, null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(10.dp)); Text(err, fontSize=12.sp, modifier=Modifier.weight(1f))
                }
            }
        }

        item { PitlineSectionHeader("ГОТОВЫЕ РОЛИКИ", "${vm.exports.size}") }
        if (vm.exports.isEmpty()) item { EmptyCard("Готовых роликов пока нет", "После локального рендера видео появится здесь.", Icons.Rounded.FileDownload) }
        else items(vm.exports, key = { it.id }) { record ->
            ExportCard(record, onPlay = { ShareUtils.openVideo(context, File(record.filePath)) }, onShare = { ShareUtils.shareVideo(context, File(record.filePath)) }, onSave = {
                toast = try { ShareUtils.saveToGallery(context, File(record.filePath)); "Сохранено в Movies / PITLINE" } catch (e: Exception) { "Не удалось сохранить: ${e.message}" }
            }, onDelete = { vm.deleteExport(record.id) })
        }
        toast?.let { item { Surface(color=Color(0xFF102019), shape=RoundedCornerShape(7.dp)) { Text(it, modifier=Modifier.padding(12.dp), color=Success, fontSize=12.sp) } } }
        item { Spacer(Modifier.height(60.dp)) }
    }
}

@Composable
private fun ExportCard(record: ExportRecord, onPlay: () -> Unit, onShare: () -> Unit, onSave: () -> Unit, onDelete: () -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(8.dp), modifier = Modifier.border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))) {
        Column {
            Box(Modifier.fillMaxWidth().height(150.dp).background(Brush.linearGradient(listOf(Color(0xFF24283A), Color(0xFF12141B)))), contentAlignment = Alignment.Center) {
                FilledIconButton(onClick = onPlay, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black), modifier = Modifier.size(58.dp)) { Icon(Icons.Rounded.PlayArrow, "Смотреть", modifier=Modifier.size(32.dp)) }
                Text(if(record.width>0) "${record.width}×${record.height}" else "MP4", modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).background(Color.Black.copy(alpha=.55f), RoundedCornerShape(7.dp)).padding(horizontal=7.dp, vertical=4.dp), fontSize=11.sp)
            }
            Column(Modifier.padding(14.dp)) {
                Text(record.title, fontWeight = FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
                Text(SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(record.createdAt)), color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick=onShare) { Icon(Icons.Rounded.Share, null, modifier=Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Поделиться") }
                    FilledTonalIconButton(onClick=onSave) { Icon(Icons.Rounded.SaveAlt, "В галерею") }
                    Spacer(Modifier.weight(1f)); IconButton(onClick=onDelete) { Icon(Icons.Rounded.DeleteOutline, "Удалить", tint=Muted) }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    var url by remember(vm.serverSettings.baseUrl) { mutableStateOf(vm.serverSettings.baseUrl) }
    var token by remember(vm.serverSettings.apiToken) { mutableStateOf(vm.serverSettings.apiToken) }
    var defaultQuality by remember(vm.appSettings.defaultQuality) { mutableStateOf(vm.appSettings.defaultQuality) }
    var defaultFps by remember(vm.appSettings.defaultFps) { mutableIntStateOf(vm.appSettings.defaultFps) }
    var defaultCodec by remember(vm.appSettings.defaultCodec) { mutableStateOf(vm.appSettings.defaultCodec) }
    var defaultRatio by remember(vm.appSettings.defaultRatio) { mutableStateOf(vm.appSettings.defaultRatio) }
    var defaultDuration by remember(vm.appSettings.defaultDurationSec) { mutableIntStateOf(vm.appSettings.defaultDurationSec) }
    var autoSave by remember(vm.appSettings.autoSaveProjects) { mutableStateOf(vm.appSettings.autoSaveProjects) }
    var appMessage by remember { mutableStateOf<String?>(null) }
    val hevcSupported = remember { hasVideoEncoder("video/hevc") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) { Icon(Icons.Rounded.ArrowBack,null) }
            Column {
                Text("НАСТРОЙКИ", fontSize=24.sp, fontWeight=FontWeight.Black)
                Text("PITLINE  •  LOCAL FIRST", color=RacingRed, fontSize=10.sp, fontWeight=FontWeight.Black, letterSpacing=1.sp)
            }
        }
        Spacer(Modifier.height(14.dp))

        Surface(color=Color(0xFF160C0A), shape=RoundedCornerShape(8.dp), modifier=Modifier.fillMaxWidth().border(1.dp,RacingRed.copy(alpha=.45f),RoundedCornerShape(8.dp))) {
            Column(Modifier.padding(16.dp)) {
                Text("ОСНОВНОЙ РЕЖИМ — ЛОКАЛЬНЫЙ", color=RacingRed, fontWeight=FontWeight.Black, fontSize=13.sp)
                Spacer(Modifier.height(6.dp))
                Text("Кнопка «Смонтировать» обрабатывает видео на устройстве. Сервер для обычного монтажа не нужен.", color=TrackWhite, fontSize=13.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        SettingCard("ПРИЛОЖЕНИЕ", Icons.Rounded.Tune) {
            ToggleLine("Автосохранение проектов", autoSave) { autoSave = it }
            Text("Клавиатуру можно закрыть тапом по пустой области экрана.", color=Muted, fontSize=11.sp)
        }

        Spacer(Modifier.height(14.dp))
        SettingCard("НОВЫЕ ПРОЕКТЫ — ПО УМОЛЧАНИЮ", Icons.Rounded.MovieCreation) {
            Text("КАЧЕСТВО", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.7.sp)
            Spacer(Modifier.height(6.dp))
            ChoiceRow(listOf("draft" to "720p", "standard" to "1080p", "high" to "1440p"), defaultQuality) { defaultQuality = it }
            Spacer(Modifier.height(11.dp))

            Text("FPS", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.7.sp)
            Spacer(Modifier.height(6.dp))
            ChoiceRow(listOf("24" to "24", "30" to "30", "60" to "60 FPS"), defaultFps.toString()) { defaultFps = it.toInt() }
            Spacer(Modifier.height(11.dp))

            Text("КОДЕК", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.7.sp)
            Spacer(Modifier.height(6.dp))
            CodecChoiceRow(defaultCodec, hevcSupported) { defaultCodec = it }
            Spacer(Modifier.height(6.dp))
            Text(if (hevcSupported) "H.265/HEVC поддерживается этим устройством." else "H.265 не найден среди аппаратных кодировщиков — используем H.264.", color=Muted, fontSize=10.sp)
            Spacer(Modifier.height(11.dp))

            Text("ФОРМАТ", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.7.sp)
            Spacer(Modifier.height(6.dp))
            ChoiceRow(listOf("9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1"), defaultRatio) { defaultRatio = it }
            Spacer(Modifier.height(11.dp))

            Text("ДЛИТЕЛЬНОСТЬ ПО УМОЛЧАНИЮ — $defaultDuration СЕК", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.5.sp)
            Slider(
                value=defaultDuration.toFloat(),
                onValueChange={ defaultDuration=((it/5).toInt()*5).coerceIn(5,180) },
                valueRange=5f..180f,
                steps=34,
                colors=SliderDefaults.colors(thumbColor=RacingRed, activeTrackColor=RacingRed)
            )
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={
                    vm.saveAppSettings(AppSettings(
                        defaultQuality=defaultQuality,
                        defaultFps=defaultFps,
                        defaultCodec=if (defaultCodec == "h265" && !hevcSupported) "h264" else defaultCodec,
                        defaultRatio=defaultRatio,
                        defaultDurationSec=defaultDuration,
                        autoSaveProjects=autoSave,
                    ))
                    appMessage="Настройки новых проектов сохранены"
                }, colors=ButtonDefaults.buttonColors(containerColor=RacingRed), shape=RoundedCornerShape(6.dp)) { Text("СОХРАНИТЬ", fontWeight=FontWeight.Black) }
                OutlinedButton(onClick={
                    vm.resetAppSettings()
                    val d=AppSettings()
                    defaultQuality=d.defaultQuality; defaultFps=d.defaultFps; defaultCodec=d.defaultCodec; defaultRatio=d.defaultRatio; defaultDuration=d.defaultDurationSec; autoSave=d.autoSaveProjects
                    appMessage="Настройки сброшены"
                }, shape=RoundedCornerShape(6.dp)) { Text("Сбросить") }
            }
            appMessage?.let { Spacer(Modifier.height(8.dp)); Text(it, color=Success, fontSize=11.sp) }
            Spacer(Modifier.height(4.dp))
            Text("Эти параметры применяются только к новым проектам. В каждом проекте их можно изменить отдельно.", color=Muted, fontSize=10.sp)
        }

        Spacer(Modifier.height(14.dp))
        Surface(color=AppCard, shape=RoundedCornerShape(8.dp), modifier=Modifier.fillMaxWidth().border(1.dp,Color(0xFF292C33),RoundedCornerShape(8.dp))) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Rounded.Cloud,null,tint=Muted); Spacer(Modifier.width(8.dp)); Text("CLOUD LAB — НЕОБЯЗАТЕЛЬНО", fontWeight=FontWeight.Black, fontSize=14.sp) }
                Spacer(Modifier.height(7.dp))
                Text("Раздел на будущее для тяжёлых AI-функций. На локальный монтаж он не влияет.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value=url,onValueChange={url=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Адрес сервера")},placeholder={Text("https://example.com")},shape=RoundedCornerShape(6.dp),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Uri))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value=token,onValueChange={token=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("API token")},visualTransformation=PasswordVisualTransformation(),shape=RoundedCornerShape(6.dp))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={vm.saveServer(url,token)}, shape=RoundedCornerShape(6.dp)) { Text("Сохранить") }
                    OutlinedButton(onClick={vm.testServer(url,token)}, shape=RoundedCornerShape(6.dp)) { Text("Проверить") }
                }
                vm.serverTest?.let { Spacer(Modifier.height(8.dp)); Text(it, color=if(it.startsWith("✓")) Success else if(it.startsWith("Ошибка")) MaterialTheme.colorScheme.error else RacingOrange, fontSize=12.sp) }
            }
        }

        Spacer(Modifier.height(14.dp))
        Surface(color=AppCard, shape=RoundedCornerShape(8.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("ПРИВАТНОСТЬ", fontWeight=FontWeight.Black, fontSize=13.sp)
                Spacer(Modifier.height(6.dp))
                Text("Локальный монтаж не отправляет исходные видео на сервер. Файлы проекта и готовые MP4 остаются на устройстве.",color=Muted,fontSize=12.sp)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun PitlineSectionHeader(title: String, meta: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(18.dp).background(RacingRed, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(8.dp))
        Text(title, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f), letterSpacing = .4.sp)
        if (meta != null) Text(meta, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SettingCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = AppCard, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))) {
        Column(Modifier.padding(14.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=RacingRed); Spacer(Modifier.width(8.dp)); Text(title,fontWeight=FontWeight.Black,fontSize=14.sp) }; Spacer(Modifier.height(11.dp)); content() }
    }
}

@Composable
private fun ChoiceRow(options: List<Pair<String,String>>, selected: String, onSelected: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { (value,label) -> FilterChip(selected=selected==value,onClick={onSelected(value)},label={Text(label)},leadingIcon=if(selected==value) {{Icon(Icons.Rounded.Check,null,modifier=Modifier.size(16.dp))}} else null) }
    }
}

@Composable
private fun CodecChoiceRow(selected: String, hevcSupported: Boolean, onSelected: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = selected == "h264", onClick = { onSelected("h264") }, label = { Text("H.264 / AVC") }, leadingIcon = if (selected == "h264") {{ Icon(Icons.Rounded.Check, null, modifier = Modifier.size(16.dp)) }} else null)
        FilterChip(selected = selected == "h265", onClick = { onSelected("h265") }, enabled = hevcSupported, label = { Text("H.265 / HEVC") }, leadingIcon = if (selected == "h265") {{ Icon(Icons.Rounded.Check, null, modifier = Modifier.size(16.dp)) }} else null)
    }
}

private fun hasVideoEncoder(mime: String): Boolean = try {
    MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.any { info ->
        info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
    }
} catch (_: Throwable) { false }

@Composable
private fun ToggleLine(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) { Text(title,Modifier.weight(1f)); Switch(checked,onCheckedChange=onChange) }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) { Text(title,fontWeight=FontWeight.Black,fontSize=18.sp,modifier=Modifier.weight(1f)); if(action!=null) TextButton(onClick=onAction){Text(action)} }
}

@Composable
private fun EmptyCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: (() -> Unit)? = null) {
    Surface(color=AppCard,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth().border(1.dp, Color(0xFF292C33), RoundedCornerShape(8.dp))) {
        Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) { Box(Modifier.size(58.dp).background(Color(0xFF242736),CircleShape),contentAlignment=Alignment.Center){Icon(icon,null,tint=Purple,modifier=Modifier.size(28.dp))}; Spacer(Modifier.height(12.dp)); Text(title,fontWeight=FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(subtitle,color=Muted,fontSize=13.sp); if(onClick!=null){Spacer(Modifier.height(12.dp));OutlinedButton(onClick=onClick){Text("Добавить видео")}} }
    }
}

@Composable
private fun Thumb(path: String?, modifier: Modifier = Modifier) {
    val bitmap = remember(path) { path?.let { BitmapFactory.decodeFile(it) } }
    if (bitmap != null) Image(bitmap.asImageBitmap(), null, modifier=modifier, contentScale=ContentScale.Crop)
    else Box(modifier.background(Color(0xFF242734)), contentAlignment=Alignment.Center) { Icon(Icons.Rounded.Movie,null,tint=Muted) }
}

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0); val m = total / 60; val s = total % 60
    return if (m > 0) "%d:%02d".format(m,s) else "0:%02d".format(s)
}
private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L*1024*1024 -> "%.1f GB".format(bytes.toDouble()/(1024*1024*1024))
    bytes >= 1024L*1024 -> "%.0f MB".format(bytes.toDouble()/(1024*1024))
    else -> "%.0f KB".format(bytes.toDouble()/1024)
}
