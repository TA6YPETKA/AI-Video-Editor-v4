package com.artem.aivideoeditor.render

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.artem.aivideoeditor.VideoEditorApp
import com.artem.aivideoeditor.data.EditProject
import com.artem.aivideoeditor.data.MediaAsset
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

@UnstableApi
class LocalRenderWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    private val transformerRef = AtomicReference<Transformer?>()
    private val main = Handler(Looper.getMainLooper())

    override fun doWork(): Result {
        val app = applicationContext as VideoEditorApp
        val projectId = inputData.getString(RenderScheduler.KEY_PROJECT_ID) ?: return Result.failure()
        val project = app.projects.get(projectId) ?: return Result.failure(error("Проект не найден"))
        val assets = project.assetIds.mapNotNull(app.library::find)
        if (assets.isEmpty()) return Result.failure(error("Исходники проекта удалены"))
        val output = app.exports.newOutputFile(projectId)
        val latch = CountDownLatch(1)
        val failure = AtomicReference<Throwable?>(null)
        val progressValue = AtomicInteger(0)

        try {
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Локальный монтаж", "Подготовка…", 0, mediaProcessing = true)).get()
            val edited = buildEditedItems(project, assets)
            val sequence = EditedMediaItemSequence.withAudioAndVideoFrom(edited)
            val composition = Composition.Builder(sequence).build()

            main.post {
                try {
                    val targetBitrate = when (project.quality.lowercase()) {
                        "draft" -> 4_500_000
                        "high" -> 14_000_000
                        else -> 8_500_000
                    }
                    val encoderFactory = DefaultEncoderFactory.Builder(applicationContext)
                        .setRequestedVideoEncoderSettings(
                            VideoEncoderSettings.Builder().setBitrate(targetBitrate).build()
                        ).build()
                    val transformer = Transformer.Builder(applicationContext)
                        .setLooper(Looper.getMainLooper())
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .setEncoderFactory(encoderFactory)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) { latch.countDown() }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                failure.set(exportException); latch.countDown()
                            }
                        }).build()
                    transformerRef.set(transformer)
                    transformer.start(composition, output.absolutePath)
                } catch (t: Throwable) { failure.set(t); latch.countDown() }
            }

            val holder = ProgressHolder()
            while (!latch.await(650, TimeUnit.MILLISECONDS)) {
                if (isStopped) {
                    main.post { try { transformerRef.get()?.cancel() } catch (_: Exception) {} }
                    output.delete(); return Result.failure(error("Отменено"))
                }
                main.post {
                    try {
                        val t = transformerRef.get() ?: return@post
                        if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) progressValue.set(holder.progress)
                    } catch (_: Exception) {}
                }
                val p = progressValue.get().coerceIn(0,99)
                setProgressAsync(progress(p, "local_render", "Рендер на устройстве ${p}%")).get()
                setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Локальный монтаж", "Рендер ${p}%", p, mediaProcessing = true)).get()
            }
            failure.get()?.let { throw it }
            if (!output.exists() || output.length() < 1024) throw IllegalStateException("Media3 не создал корректный MP4")
            val record = app.exports.register(projectId, project.title, output)
            setForegroundAsync(renderForegroundInfo(applicationContext, id.hashCode(), "Готово", "Локальный MP4 создан", 100, mediaProcessing = true)).get()
            return Result.success(Data.Builder().putString(RenderScheduler.KEY_EXPORT_ID, record.id)
                .putString(RenderScheduler.KEY_OUTPUT_PATH, record.filePath).build())
        } catch (t: Throwable) {
            output.delete(); return Result.failure(error(t.message ?: t.javaClass.simpleName))
        } finally { transformerRef.set(null) }
    }

    override fun onStopped() {
        main.post { try { transformerRef.get()?.cancel() } catch (_: Exception) {} }
        super.onStopped()
    }

    private fun buildEditedItems(project: EditProject, assets: List<MediaAsset>): List<EditedMediaItem> {
        val targetMs = project.durationSec.coerceIn(3, 180) * 1000L
        val prompt = project.prompt.lowercase()
        val style = project.style.lowercase()

        // PITLINE local planner: the prompt/style controls edit tempo without any server.
        // It deliberately samples inside clips instead of always taking the first seconds,
        // which makes local edits feel more like an actual cut and less like concatenation.
        val baseCutMs = when {
            style == "gaming" || prompt.contains("gaming") || prompt.contains("игров") || prompt.contains("экшен") -> 1_850L
            style == "dynamic" || prompt.contains("динамич") || prompt.contains("быстр") || prompt.contains("коротк") -> 2_150L
            style == "ad" || prompt.contains("реклам") || prompt.contains("товар") || prompt.contains("продукт") -> 2_450L
            style == "cinematic" || prompt.contains("cinematic") || prompt.contains("кинемат") || prompt.contains("спокой") || prompt.contains("атмосфер") -> 4_800L
            style == "talking" || prompt.contains("влог") || prompt.contains("говорящ") || prompt.contains("интервью") -> 3_600L
            else -> 3_000L
        }

        val longEdge = if (project.quality.lowercase() == "draft") 1280 else 1920
        val shortEdge = if (project.quality.lowercase() == "draft") 720 else 1080
        val square = if (project.quality.lowercase() == "draft") 720 else 1080
        val (w, h) = when (project.ratio) {
            "16:9" -> longEdge to shortEdge
            "1:1" -> square to square
            else -> shortEdge to longEdge
        }
        val presentation = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        val effects = Effects(emptyList(), listOf(presentation))

        val ordered = when {
            style == "dynamic" || style == "gaming" -> assets.sortedByDescending { it.durationMs }
            style == "ad" -> assets.sortedByDescending { it.width.toLong() * it.height.toLong() }
            else -> assets
        }

        val result = mutableListOf<EditedMediaItem>()
        var remaining = targetMs
        var index = 0
        val maxSegments = 96

        while (remaining > 250L && result.size < maxSegments) {
            val asset = ordered[index % ordered.size]
            val sourceDuration = asset.durationMs.takeIf { it > 350L } ?: baseCutMs
            val rhythmJitter = when (index % 4) {
                0 -> 0L
                1 -> -250L
                2 -> 180L
                else -> -90L
            }
            val wanted = (baseCutMs + rhythmJitter).coerceAtLeast(850L)
            val segmentMs = minOf(wanted, sourceDuration, remaining).coerceAtLeast(250L)

            val startMs = if (sourceDuration <= segmentMs + 200L) {
                0L
            } else {
                val available = sourceDuration - segmentMs
                val phase = ((index * 37 + 17) % 100) / 100.0
                val bias = when {
                    index == 0 && (prompt.contains("сильн") || prompt.contains("хук") || style == "ad") -> 0.42
                    style == "talking" -> 0.12
                    else -> 0.12 + phase * 0.72
                }
                (available * bias).toLong().coerceIn(0L, available)
            }
            val endMs = (startMs + segmentMs).coerceAtMost(sourceDuration)

            val media = MediaItem.Builder()
                .setUri(Uri.fromFile(File(asset.filePath)))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()

            result += EditedMediaItem.Builder(media)
                .setFlattenForSlowMotion(true)
                .setFrameRate(project.fps.coerceIn(24, 60))
                .setEffects(effects)
                .build()

            remaining -= (endMs - startMs).coerceAtLeast(1L)
            index++
        }

        if (result.isEmpty()) {
            val asset = assets.first()
            val media = MediaItem.Builder().setUri(Uri.fromFile(File(asset.filePath))).build()
            result += EditedMediaItem.Builder(media)
                .setFlattenForSlowMotion(true)
                .setFrameRate(project.fps.coerceIn(24, 60))
                .setEffects(effects)
                .build()
        }
        return result
    }

    private fun progress(value: Int, stage: String, message: String) = Data.Builder().putInt("progress", value)
        .putString(RenderScheduler.KEY_STAGE, stage).putString("message", message).build()
    private fun error(message: String) = Data.Builder().putString("error", message.take(1500)).build()
}
