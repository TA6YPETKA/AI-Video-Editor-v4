package com.artem.aivideoeditor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AppBg = Color(0xFF050608)
val AppCard = Color(0xFF0E1014)
val AppCard2 = Color(0xFF171A20)
val RacingRed = Color(0xFFFF3B22)
val RacingOrange = Color(0xFFFF5C2A)
val TrackWhite = Color(0xFFF7F3EE)
val TrackGray = Color(0xFF252931)
val Purple = RacingRed
val Cyan = RacingOrange
val Pink = Color(0xFFFF725A)
val Success = Color(0xFF63E6A6)
val Muted = Color(0xFF959AA5)

private val scheme = darkColorScheme(
    primary = RacingRed,
    secondary = RacingOrange,
    tertiary = TrackWhite,
    background = AppBg,
    surface = AppCard,
    surfaceVariant = AppCard2,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = TrackWhite,
    onSurface = TrackWhite,
    onSurfaceVariant = Color(0xFFC0C4CC),
    error = Color(0xFFFF5D5D),
)

private val pitlineTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 44.sp, letterSpacing = (-1.2f).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = (-0.6f).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, letterSpacing = (-0.3f).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 15.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 13.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 0.2.sp),
)

@Composable
fun AIVideoEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = pitlineTypography, content = content)
}
