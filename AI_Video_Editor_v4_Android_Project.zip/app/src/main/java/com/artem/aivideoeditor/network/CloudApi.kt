package com.artem.aivideoeditor.network

import com.artem.aivideoeditor.data.CloudJobStatus
import com.artem.aivideoeditor.data.EditProject
import com.artem.aivideoeditor.data.MediaAsset
import com.artem.aivideoeditor.data.ServerSettings
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

class CloudApi(private val settings: ServerSettings) {
    private val base = settings.baseUrl.trimEnd('/')

    fun health(): JSONObject = requestJson("GET", "/api/health")

    fun createJob(project: EditProject, assets: List<MediaAsset>): String {
        require(base.isNotBlank()) { "Адрес сервера не задан" }
        require(assets.isNotEmpty()) { "В проекте нет видео" }
        val boundary = "----AIVideoEditor${UUID.randomUUID()}"
        val conn = connection("POST", "/api/jobs").apply {
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            chunkedStreamingMode = 1024 * 1024
            connectTimeout = 20_000
            readTimeout = 60_000
        }
        BufferedOutputStream(conn.outputStream, 1024 * 1024).use { out ->
            fun text(name: String, value: String) {
                out.write("--$boundary\r\n".toByteArray())
                out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
                out.write(value.toByteArray(StandardCharsets.UTF_8)); out.write("\r\n".toByteArray())
            }
            text("prompt", project.prompt)
            text("ratio", project.ratio)
            text("duration", project.durationSec.toString())
            text("style", mapStyle(project.style))
            text("quality", project.quality)
            text("fps", project.fps.toString())
            text("remove_pauses", project.removePauses.toString())
            text("captions", project.captions.toString())
            text("semantic_ai", "true")
            text("beat_sync", project.beatSync.toString())
            text("framing", "smart")
            text("transition", "auto")
            text("keep_original_audio", "true")
            text("music_volume", "0.22")
            text("transcription_provider", "auto")
            assets.forEachIndexed { index, asset ->
                val file = File(asset.filePath)
                out.write("--$boundary\r\n".toByteArray())
                out.write("Content-Disposition: form-data; name=\"files\"; filename=\"clip_${index}.mp4\"\r\n".toByteArray())
                out.write("Content-Type: video/mp4\r\n\r\n".toByteArray())
                FileInputStream(file).use { input ->
                    val buf = ByteArray(1024 * 1024)
                    while (true) {
                        if (Thread.currentThread().isInterrupted) throw InterruptedException("Upload cancelled")
                        val n = input.read(buf); if (n <= 0) break; out.write(buf, 0, n)
                    }
                }
                out.write("\r\n".toByteArray())
            }
            out.write("--$boundary--\r\n".toByteArray()); out.flush()
        }
        val body = readResponse(conn)
        if (conn.responseCode !in 200..299) throw ApiException(conn.responseCode, errorMessage(body))
        return JSONObject(body).getString("job_id")
    }

    fun job(jobId: String): CloudJobStatus {
        val o = requestJson("GET", "/api/jobs/${enc(jobId)}")
        val result = o.optJSONObject("result")
        return CloudJobStatus(
            id = jobId,
            status = o.optString("status", "unknown"),
            progress = o.optInt("progress", 0).coerceIn(0,100),
            stage = o.optString("stage", ""),
            message = o.optString("message", ""),
            error = o.optString("error").takeIf { it.isNotBlank() && it != "null" },
            downloadUrl = result?.optString("download_url")?.takeIf { it.isNotBlank() },
        )
    }

    fun cancel(jobId: String) { requestJson("POST", "/api/jobs/${enc(jobId)}/cancel") }

    fun delete(jobId: String) {
        try { requestJson("DELETE", "/api/jobs/${enc(jobId)}") } catch (_: Exception) {}
    }

    fun download(jobId: String, destination: File, onProgress: (Int) -> Unit = {}) {
        val conn = connection("GET", "/api/jobs/${enc(jobId)}/download").apply {
            connectTimeout = 20_000; readTimeout = 60_000
        }
        if (conn.responseCode !in 200..299) {
            val body = readResponse(conn); throw ApiException(conn.responseCode, errorMessage(body))
        }
        val total = conn.contentLengthLong
        val part = File(destination.parentFile, ".${destination.name}.part")
        var copied = 0L
        BufferedInputStream(conn.inputStream, 1024 * 1024).use { input ->
            FileOutputStream(part).use { fos -> BufferedOutputStream(fos, 1024 * 1024).use { out ->
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("Download cancelled")
                    val n = input.read(buf); if (n <= 0) break
                    out.write(buf,0,n); copied += n
                    if (total > 0) onProgress(((copied * 100) / total).toInt().coerceIn(0,100))
                }
                out.flush(); fos.fd.sync()
            }}
        }
        if (part.length() <= 0) { part.delete(); error("Сервер вернул пустой MP4") }
        if (!part.renameTo(destination)) { part.copyTo(destination, overwrite = true); part.delete() }
        onProgress(100)
    }

    private fun requestJson(method: String, path: String): JSONObject {
        val conn = connection(method, path).apply { connectTimeout = 12_000; readTimeout = 25_000 }
        if (method == "POST") { doOutput = true; outputStream.use { } }
        val body = readResponse(conn)
        if (conn.responseCode !in 200..299) throw ApiException(conn.responseCode, errorMessage(body))
        return if (body.isBlank()) JSONObject() else JSONObject(body)
    }

    private fun connection(method: String, path: String): HttpURLConnection {
        require(base.startsWith("http://") || base.startsWith("https://")) { "Адрес должен начинаться с http:// или https://" }
        return (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            useCaches = false
            setRequestProperty("Accept", "application/json")
            if (settings.apiToken.isNotBlank()) setRequestProperty("Authorization", "Bearer ${settings.apiToken}")
        }
    }

    private fun readResponse(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
    }

    private fun errorMessage(body: String): String = try {
        JSONObject(body).optString("detail").ifBlank { body.take(500) }
    } catch (_: Exception) { body.take(500).ifBlank { "Ошибка сервера" } }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun mapStyle(style: String) = when (style.lowercase()) {
        "gaming" -> "dynamic"
        "reels", "shorts" -> "dynamic"
        else -> style.lowercase().takeIf { it in setOf("auto","dynamic","ad","cinematic","talking","balanced") } ?: "auto"
    }
}

class ApiException(val code: Int, message: String): Exception("HTTP $code: $message")
